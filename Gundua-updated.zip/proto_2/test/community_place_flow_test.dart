import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:proto_2/screens/add_place_screen.dart';
import 'package:proto_2/screens/explore_screen.dart';
import 'package:proto_2/screens/home_screen.dart';
import 'package:proto_2/screens/main_navigation_screen.dart';
import 'package:proto_2/theme/gundua_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('a place added from Explore appears in Home and search', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    tester.view
      ..devicePixelRatio = 1
      ..physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        theme: GunduaTheme.light(),
        home: const MainNavigationScreen(),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Destaques da Semana').hitTestable(), findsOneWidget);

    await tester.tap(find.text('Explorar'));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('Adicionar lugar'));
    await tester.pumpAndSettle();

    const name = 'Museu da Rua Nova';
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nome do lugar'),
      name,
    );
    await tester.tap(find.byType(DropdownButtonFormField<String>));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Museus').last);
    await tester.pumpAndSettle();
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Morada ou localização'),
      'Rua Nova, Lisboa',
    );
    final description = find.widgetWithText(TextFormField, 'Descrição');
    await tester.scrollUntilVisible(
      description,
      100,
      scrollable: find
          .descendant(
            of: find.byType(AddPlaceScreen),
            matching: find.byType(Scrollable),
          )
          .first,
    );
    await tester.enterText(description, 'Uma coleção de azulejos.');
    final submit = find.widgetWithText(FilledButton, 'Guardar lugar');
    await tester.ensureVisible(submit);
    await tester.tap(submit);
    await tester.pumpAndSettle();

    final explore = find.byType(ExploreScreen);
    final home = find.byType(HomeScreen);
    expect(
      find.descendant(of: explore, matching: find.text(name)),
      findsOneWidget,
    );

    await tester.tap(find.text('Início'));
    await tester.pumpAndSettle();
    final homePlace = find.descendant(of: home, matching: find.text(name));
    await tester.scrollUntilVisible(
      homePlace,
      220,
      scrollable: find
          .descendant(of: home, matching: find.byType(Scrollable))
          .first,
    );
    expect(homePlace, findsOneWidget);

    await tester.tap(find.text('Explorar'));
    await tester.pumpAndSettle();
    final search = find
        .descendant(of: explore, matching: find.byType(TextField))
        .last;
    await tester.enterText(search, 'rua nova');
    await tester.testTextInput.receiveAction(TextInputAction.search);
    await tester.pumpAndSettle();
    expect(find.text('Resultados da pesquisa').hitTestable(), findsOneWidget);
    expect(
      find.descendant(of: explore, matching: find.text(name)).hitTestable(),
      findsOneWidget,
    );
  });
}
