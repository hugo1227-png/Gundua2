import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/community_places_service.dart';
import '../services/place_search_service.dart';
import '../theme/gundua_theme.dart';

class AddPlaceScreen extends StatefulWidget {
  const AddPlaceScreen({super.key});

  @override
  State<AddPlaceScreen> createState() => _AddPlaceScreenState();
}

class _AddPlaceScreenState extends State<AddPlaceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _address = TextEditingController();
  final _description = TextEditingController();
  final _picker = ImagePicker();

  String? _category;
  Uint8List? _photo;
  bool _picking = false;
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _address.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    if (_picking || _saving) return;
    setState(() => _picking = true);
    try {
      final image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 80,
      );
      if (image == null || !mounted) return;
      if (await image.length() > CommunityPlacesService.maxPhotoBytes) {
        _showMessage('Escolhe uma fotografia até 1 MB.');
        return;
      }
      final bytes = await image.readAsBytes();
      if (mounted) setState(() => _photo = bytes);
    } catch (_) {
      _showMessage('Não foi possível abrir a fotografia. Tenta outra imagem.');
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  Future<void> _save() async {
    if (_saving || _picking || !_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() => _saving = true);
    final category = _category!;
    try {
      final place = await CommunityPlacesService.instance.add(
        name: _name.text,
        category: category,
        categories: [
          PlaceSearchService.categoryFilters[category]!.split(',').first,
        ],
        address: _address.text,
        description: _description.text,
        photo: _photo,
      );
      if (mounted) Navigator.of(context).pop(place);
    } catch (_) {
      _showMessage('Não foi possível guardar o lugar. Tenta novamente.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String? _required(String? value) =>
      value == null || value.trim().isEmpty ? 'Preenche este campo.' : null;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Adicionar lugar')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Form(
              key: _formKey,
              child: ListView(
                shrinkWrap: true,
                padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
                children: [
                  Text(
                    'O lugar fica disponível nas tuas listas e pesquisas neste dispositivo.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: GunduaTheme.muted,
                    ),
                  ),
                  const SizedBox(height: 22),
                  _photoPicker(theme),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _name,
                    enabled: !_saving,
                    maxLength: 80,
                    textInputAction: TextInputAction.next,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Nome do lugar',
                      prefixIcon: Icon(Icons.place_outlined),
                    ),
                    validator: _required,
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _category,
                    isExpanded: true,
                    items: [
                      for (final category
                          in PlaceSearchService.categoryFilters.keys)
                        DropdownMenuItem(
                          value: category,
                          child: Text(category),
                        ),
                    ],
                    onChanged: _saving
                        ? null
                        : (value) => setState(() => _category = value),
                    validator: (value) =>
                        value == null ? 'Escolhe uma categoria.' : null,
                    decoration: const InputDecoration(
                      labelText: 'Categoria',
                      prefixIcon: Icon(Icons.category_outlined),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _address,
                    enabled: !_saving,
                    maxLength: 160,
                    textInputAction: TextInputAction.next,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      labelText: 'Morada ou localização',
                      hintText: 'Rua, bairro e cidade',
                      prefixIcon: Icon(Icons.location_on_outlined),
                    ),
                    validator: _required,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _description,
                    enabled: !_saving,
                    minLines: 3,
                    maxLines: 5,
                    maxLength: 480,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      labelText: 'Descrição',
                      hintText: 'O que torna este lugar especial?',
                      alignLabelWithHint: true,
                    ),
                    validator: _required,
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _saving || _picking ? null : _save,
                    icon: _saving
                        ? const SizedBox.square(
                            dimension: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.add_location_alt_outlined),
                    label: Text(_saving ? 'A guardar…' : 'Guardar lugar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _photoPicker(ThemeData theme) {
    final photo = _photo;
    return Material(
      color: theme.colorScheme.primaryContainer,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          if (photo != null)
            SizedBox(
              width: double.infinity,
              height: 160,
              child: Image.memory(photo, fit: BoxFit.cover),
            ),
          InkWell(
            onTap: _saving || _picking ? null : _pickPhoto,
            child: SizedBox(
              width: double.infinity,
              height: 160,
              child: photo == null || _picking
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (_picking)
                          const SizedBox.square(
                            dimension: 23,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        else
                          Icon(
                            Icons.add_a_photo_outlined,
                            size: 28,
                            color: theme.colorScheme.onPrimaryContainer,
                          ),
                        const SizedBox(height: 9),
                        Text(
                          _picking
                              ? 'A abrir galeria…'
                              : 'Adicionar fotografia',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer,
                          ),
                        ),
                        if (!_picking)
                          Text('Opcional', style: theme.textTheme.bodySmall),
                      ],
                    )
                  : Align(
                      alignment: Alignment.bottomLeft,
                      child: Container(
                        margin: const EdgeInsets.all(12),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text('Alterar fotografia'),
                      ),
                    ),
            ),
          ),
          if (photo != null && !_picking)
            Padding(
              padding: const EdgeInsets.all(6),
              child: IconButton.filledTonal(
                onPressed: _saving ? null : () => setState(() => _photo = null),
                tooltip: 'Remover fotografia',
                icon: const Icon(Icons.close),
              ),
            ),
        ],
      ),
    );
  }
}
