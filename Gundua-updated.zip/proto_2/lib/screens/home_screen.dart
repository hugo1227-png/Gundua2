import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../models/place.dart';
import '../services/community_places_service.dart';
import '../services/curated_places_service.dart';
import '../services/favorites_service.dart';
import '../services/gundua_api_client.dart';
import '../services/location_service.dart';
import '../services/place_service.dart';
import '../services/recently_viewed_service.dart';
import '../services/weekly_highlights_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/gundua_brand.dart';
import '../widgets/home_highlights.dart';
import '../widgets/location_picker.dart';
import '../widgets/place_carousel_card.dart';
import '../widgets/place_photo.dart';
import 'friends_feed.dart';
import 'nearby_map_screen.dart';
import 'place_details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    this.onGoExplore,
    this.onSearch,
    this.onAddPlace,
    this.refreshToken = 0,
  });

  final VoidCallback? onGoExplore;
  final ValueChanged<String>? onSearch;
  final VoidCallback? onAddPlace;
  final int refreshToken;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const Color background = GunduaTheme.canvas;
  static const Color textColor = GunduaTheme.ink;
  static const Color secondaryColor = GunduaTheme.muted;
  static const Color accentColor = GunduaTheme.accent;
  static const Color cardColor = GunduaTheme.surface;
  // Centro de Lisboa: serve apenas para procurar o Top 100 de Lisboa,
  // nunca substitui a localização do utilizador.
  static const double lisbonLatitude = 38.7223;
  static const double lisbonLongitude = -9.1393;

  final TextEditingController _searchController = TextEditingController();
  final PlaceService _placeService = PlaceService();
  final FavoritesService _favoritesService = FavoritesService();
  final RecentlyViewedService _recentlyViewedService = RecentlyViewedService();
  final CommunityPlacesService _communityPlaces =
      CommunityPlacesService.instance;

  List<Map<String, dynamic>> _recentlyViewedPlaces = [];
  List<Place> _hiddenGems = CuratedPlacesService.lisbonHiddenGems
      .map(Place.fromMap)
      .toList();
  List<Place> _topPlaces = [];
  List<Place> _ratedTopPlaces = [];
  Map<String, dynamic>? _weeklyPlace;
  String? _ratingsError;
  bool _loadingRatings = false;
  int _locationRequestId = 0;
  int _ratingsRequestId = 0;
  int _weeklyRequestId = 0;
  final Set<String> _favoritePlaceIds = {};
  final Set<String> _busyFavoriteIds = {};
  final Map<String, Future<String?>> _imageFutures = {};

  String _locationName = 'Localização por definir';
  bool _loadingRecentlyViewed = true;
  bool _isLoadingNearby = false;
  AppLocation? _selectedLocation;
  int _homeTab = 0;
  bool _openingPlace = false;
  String? _nearbyError;

  @override
  void initState() {
    super.initState();
    LocationPreferenceService.selection.addListener(_onLocationChanged);
    _loadRatedPlaces();
    _loadWeeklyHighlight();
    _loadRecentlyViewed();
    _loadFavoriteIds();
    _restoreSelectedLocation();
    _communityPlaces.load();
  }

  @override
  void didUpdateWidget(covariant HomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) {
      _loadRecentlyViewed();
      _loadFavoriteIds();
      _loadWeeklyHighlight();
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _locationRequestId++;
    _ratingsRequestId++;
    LocationPreferenceService.selection.removeListener(_onLocationChanged);
    super.dispose();
  }

  Future<void> _loadRecentlyViewed() async {
    try {
      final places = await _recentlyViewedService.getRecentlyViewed();
      if (!mounted) {
        return;
      }
      setState(() {
        _recentlyViewedPlaces = places;
        _loadingRecentlyViewed = false;
      });
    } catch (error) {
      debugPrint('Erro ao carregar histórico: $error');
      if (mounted) {
        setState(() => _loadingRecentlyViewed = false);
      }
    }
  }

  Future<void> _loadFavoriteIds() async {
    try {
      final favorites = await _favoritesService.getFavorites();
      if (!mounted) {
        return;
      }
      setState(() {
        _favoritePlaceIds
          ..clear()
          ..addAll(favorites.map(_favoritesService.getPlaceId));
      });
    } catch (error) {
      debugPrint('Erro ao carregar favoritos: $error');
    }
  }

  Future<void> _clearRecentlyViewed() async {
    await _recentlyViewedService.clear();
    if (!mounted) {
      return;
    }
    setState(() => _recentlyViewedPlaces = []);
  }

  void _submitSearch() {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      widget.onGoExplore?.call();
      return;
    }
    FocusScope.of(context).unfocus();
    widget.onSearch?.call(query);
  }

  Future<void> _loadWeeklyHighlight() async {
    final requestId = ++_weeklyRequestId;
    final service = WeeklyHighlightsService();
    Map<String, dynamic>? place;
    if (GunduaApiClient.isConfigured) {
      try {
        place = await service.communityMostVisited();
      } catch (error) {
        debugPrint(
          'Não foi possível carregar o destaque da comunidade: $error',
        );
      }
    }
    try {
      place ??= await service.mostViewedByMe();
      if (mounted && requestId == _weeklyRequestId) {
        setState(() => _weeklyPlace = place);
      }
    } catch (error) {
      debugPrint('Não foi possível carregar o destaque semanal: $error');
    }
  }

  void _onLocationChanged() {
    final location = LocationPreferenceService.selection.value;
    if (!mounted || location == null) {
      return;
    }
    if (_selectedLocation?.latitude == location.latitude &&
        _selectedLocation?.longitude == location.longitude &&
        _selectedLocation?.label == location.label) {
      return;
    }
    setState(() => _selectedLocation = location);
    _loadNearbyContent(location: location);
  }

  Future<void> _restoreSelectedLocation() async {
    final location = await LocationPreferenceService().getSelected();
    if (!mounted || location == null) {
      return;
    }
    if (_selectedLocation?.latitude == location.latitude &&
        _selectedLocation?.longitude == location.longitude) {
      return;
    }
    setState(() => _selectedLocation = location);
    await _loadNearbyContent(location: location);
  }

  Future<void> _chooseLocation() async {
    await LocationPicker.show(context);
    // LocationPicker persiste a selecção; o listener actualiza as páginas.
  }

  Future<void> _loadNearbyContent({AppLocation? location}) async {
    final requestId = ++_locationRequestId;
    final selected = location ?? _selectedLocation;
    if (selected == null) {
      return;
    }

    setState(() {
      _isLoadingNearby = true;
      _locationName = selected.label;
      _nearbyError = null;
    });

    try {
      final nearby = await _placeService.getNearbyPlaces(
        latitude: selected.latitude,
        longitude: selected.longitude,
        radiusMeters: 20000,
        limit: 100,
        categoryFilter:
            'tourism,entertainment,leisure.park,beach,catering.restaurant',
      );

      final places = <Place>[];
      final seen = <String>{};
      for (final item in nearby) {
        final place = Place.fromMap(item);
        if (place.latitude == 0 && place.longitude == 0) {
          continue;
        }
        if (!seen.add(place.id)) {
          continue;
        }
        final distance = Geolocator.distanceBetween(
          selected.latitude,
          selected.longitude,
          place.latitude,
          place.longitude,
        );
        if (distance <= 20000) {
          places.add(place.copyWith(distanceMeters: distance));
        }
      }
      places.sort(
        (a, b) => (a.distanceMeters ?? 0).compareTo(b.distanceMeters ?? 0),
      );

      final gems = _hiddenGems.map((place) {
        final distance = Geolocator.distanceBetween(
          selected.latitude,
          selected.longitude,
          place.latitude,
          place.longitude,
        );
        return place.copyWith(distanceMeters: distance);
      }).toList();

      if (!mounted || requestId != _locationRequestId) {
        return;
      }
      setState(() {
        _topPlaces = places.take(100).toList();
        _hiddenGems = gems;
        _isLoadingNearby = false;
      });
    } catch (error) {
      if (!mounted || requestId != _locationRequestId) {
        return;
      }
      setState(() {
        _isLoadingNearby = false;
        _nearbyError =
            'Não foi possível carregar lugares próximos. Tenta novamente.';
      });
    }
  }

  Future<void> _loadRatedPlaces() async {
    final requestId = ++_ratingsRequestId;
    setState(() {
      _loadingRatings = true;
      _ratedTopPlaces = [];
      _ratingsError = null;
    });
    try {
      final rated = await _placeService.getGoogleTop100Places(
        latitude: lisbonLatitude,
        longitude: lisbonLongitude,
      );
      final places = rated.map(Place.fromMap).toList();
      if (!mounted || requestId != _ratingsRequestId) {
        return;
      }
      setState(() {
        _ratedTopPlaces = places;
        _loadingRatings = false;
      });
    } catch (error) {
      if (!mounted || requestId != _ratingsRequestId) {
        return;
      }
      setState(() {
        _loadingRatings = false;
        _ratingsError = error is PlaceRatingsUnavailable
            ? error.message
            : 'Classificações indisponíveis de momento.';
      });
    }
  }

  Widget _buildWeeklyHighlights() {
    final featured = _weeklyPlace;
    final featuredPlace = featured == null ? null : Place.fromMap(featured);
    final today = DateTime.now();
    final calendarDay = DateTime.utc(today.year, today.month, today.day);
    // Use the local calendar's Monday boundary, independent of DST.
    final week =
        calendarDay.add(const Duration(days: 3)).millisecondsSinceEpoch ~/
        const Duration(days: 7).inMilliseconds;
    final start = week % _hiddenGems.length;
    final illustrated = _hiddenGems
        .where(
          (place) => CuratedPlacesService.photoAssets.containsKey(place.id),
        )
        .toList();
    final lead =
        featuredPlace ??
        (illustrated.isEmpty
            ? _hiddenGems[start]
            : illustrated[week % illustrated.length]);
    final curated = [
      ..._hiddenGems.skip(start),
      ..._hiddenGems.take(start),
    ].where((place) => place.id != lead.id);
    final picks = [
      (
        place: lead,
        note: featured == null
            ? _locality(lead)
            : featured.containsKey('weeklyCommunityVisitCount')
            ? 'Mais visitado pela comunidade'
            : 'O teu local mais visto esta semana',
      ),
      for (final place in curated.take(2))
        (place: place, note: _locality(place)),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: GunduaTheme.pageInset),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (var i = 0; i < picks.length; i++) ...[
            if (i > 0) const SizedBox(width: 12),
            SizedBox(
              width: 278,
              child: WeeklyHighlightCard(
                place: picks[i].place,
                note: picks[i].note,
                onOpen: () => _openPlace(picks[i].place.toMap()),
                photoAsset: CuratedPlacesService.photoAssets[picks[i].place.id],
                imageFuture:
                    CuratedPlacesService.photoAssets.containsKey(
                      picks[i].place.id,
                    )
                    ? null
                    : _imageFuture(picks[i].place),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCommunityPlaces() {
    return ListenableBuilder(
      listenable: _communityPlaces,
      builder: (context, _) {
        final places = _communityPlaces.places;
        if (places.isEmpty && widget.onAddPlace == null) {
          return const SizedBox.shrink();
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle(
              'Os teus lugares',
              '',
              action: widget.onAddPlace == null
                  ? null
                  : TextButton.icon(
                      onPressed: widget.onAddPlace,
                      icon: const Icon(Icons.add_rounded, size: 18),
                      label: const Text('Adicionar lugar'),
                    ),
            ),
            if (places.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: GunduaTheme.pageInset,
                ),
                child: Text(
                  'Conheces um lugar que merece ser descoberto? Guarda-o na Gundua.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              )
            else
              SizedBox(
                height: 244,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(
                    horizontal: GunduaTheme.pageInset,
                  ),
                  scrollDirection: Axis.horizontal,
                  itemCount: places.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 12),
                  itemBuilder: (context, index) =>
                      SizedBox(width: 220, child: _buildGemCard(places[index])),
                ),
              ),
          ],
        );
      },
    );
  }

  Future<void> _toggleFavorite(Place place) async {
    final id = _favoritesService.getPlaceId(place.toMap());
    if (_busyFavoriteIds.contains(id)) return;
    setState(() => _busyFavoriteIds.add(id));
    try {
      final saved = await _favoritesService.toggleFavorite(place.toMap());
      if (!mounted) {
        return;
      }
      setState(() {
        if (saved) {
          _favoritePlaceIds.add(id);
        } else {
          _favoritePlaceIds.remove(id);
        }
      });
    } catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível guardar o favorito.')),
      );
    } finally {
      if (mounted) setState(() => _busyFavoriteIds.remove(id));
    }
  }

  Future<String?>? _imageFuture(Place place) {
    if (place.isCommunityPlace || place.imageUrl?.isNotEmpty == true) {
      return null;
    }
    return _imageFutures.putIfAbsent(
      place.id,
      () => _placeService.searchPlaceImage(
        [
          place.name,
          place.locality ?? place.address,
        ].where((part) => part.trim().isNotEmpty).join(', '),
      ),
    );
  }

  Future<void> _openPlace(Map<String, dynamic> place) async {
    if (_openingPlace) {
      return;
    }
    _openingPlace = true;
    final navigator = Navigator.of(context);
    try {
      await navigator.push(
        MaterialPageRoute<void>(
          builder: (_) =>
              PlaceDetailsScreen(place: Map<String, dynamic>.from(place)),
        ),
      );
      if (!mounted) {
        return;
      }
      await _loadRecentlyViewed();
      await _loadFavoriteIds();
      await _loadWeeklyHighlight();
    } catch (error, stackTrace) {
      debugPrint('Não foi possível abrir os detalhes: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir este local.')),
      );
    } finally {
      _openingPlace = false;
    }
  }

  String _formatDistance(double? meters) {
    if (meters == null) {
      return 'Distância por calcular';
    }
    if (meters < 1000) {
      return '${meters.round()} m';
    }
    return '${(meters / 1000).toStringAsFixed(1)} km';
  }

  String _locality(Place place) {
    if (place.locality?.trim().isNotEmpty == true) {
      return place.locality!;
    }
    final parts = place.address.split(',').map((part) => part.trim()).toList();
    return parts.length > 1 ? parts[parts.length - 2] : place.address;
  }

  Widget _sectionTitle(String title, String subtitle, {Widget? action}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 28, 22, 13),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: textColor,
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5,
                  ),
                ),
                if (subtitle.isNotEmpty) ...[
                  const SizedBox(height: 5),
                  Text(
                    subtitle,
                    style: const TextStyle(color: secondaryColor, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          ?action,
        ],
      ),
    );
  }

  Widget _placeImage(Place place) =>
      PlacePhoto(url: place.imageUrl, imageFuture: _imageFuture(place));

  Widget _buildGemCard(Place place) {
    final id = _favoritesService.getPlaceId(place.toMap());
    return PlaceCarouselCard(
      place: place,
      onTap: () => _openPlace(place.toMap()),
      onFavorite: () => _toggleFavorite(place),
      isFavorite: _favoritePlaceIds.contains(id),
      favoriteBusy: _busyFavoriteIds.contains(id),
      imageFuture: _imageFuture(place),
    );
  }

  Widget _buildTopCard(Place place, int index) {
    return Material(
      color: cardColor,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _openPlace(place.toMap()),
        splashColor: accentColor.withValues(alpha: 0.10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  _placeImage(place),
                  Positioned(
                    left: 9,
                    top: 9,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: textColor,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        '#${index + 1}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(11),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    place.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: textColor,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _locality(place),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: secondaryColor, fontSize: 10),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (place.rating != null) ...[
                        const Icon(
                          Icons.star_rounded,
                          color: Color(0xFFE2A827),
                          size: 13,
                        ),
                        Text(
                          ' ${place.rating!.toStringAsFixed(1)}',
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                      ],
                      if (place.distanceMeters != null)
                        Text(
                          _formatDistance(place.distanceMeters),
                          style: const TextStyle(
                            color: textColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationMessage() {
    final message =
        _nearbyError ?? 'Escolhe uma cidade ou ativa a localização.';
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 22),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: GunduaTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            message,
            style: const TextStyle(
              color: secondaryColor,
              fontSize: 12,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: _isLoadingNearby ? null : _chooseLocation,
            icon: _isLoadingNearby
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: accentColor,
                    ),
                  )
                : const Icon(Icons.my_location_outlined, size: 17),
            label: Text(
              _isLoadingNearby ? 'A localizar...' : 'Escolher localização',
            ),
            style: TextButton.styleFrom(foregroundColor: accentColor),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeTabs() {
    const tabs = [
      (label: 'Para ti', icon: Icons.explore_outlined),
      (label: 'Amigos', icon: Icons.people_outline_rounded),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 0, 22, 16),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Material(
          color: GunduaTheme.cream,
          shape: const StadiumBorder(side: BorderSide(color: GunduaTheme.line)),
          clipBehavior: Clip.antiAlias,
          child: Padding(
            padding: const EdgeInsets.all(3),
            child: Wrap(
              children: [
                for (var index = 0; index < tabs.length; index++)
                  Semantics(
                    selected: _homeTab == index,
                    child: TextButton.icon(
                      onPressed: () {
                        if (index == _homeTab) return;
                        setState(() => _homeTab = index);
                        if (index == 0) _loadFavoriteIds();
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        minimumSize: const Size(0, 44),
                        foregroundColor: _homeTab == index
                            ? Colors.white
                            : secondaryColor,
                        backgroundColor: _homeTab == index ? accentColor : null,
                      ),
                      icon: Icon(tabs[index].icon, size: 17),
                      label: Text(tabs[index].label),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 15, 20, 16),
                child: Row(
                  children: [
                    const GunduaBrandMark(size: 34),
                    const SizedBox(width: 8),
                    const GunduaWordmark(),
                    const Spacer(),
                    IconButton.filledTonal(
                      tooltip: 'Mapa de descoberta',
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NearbyMapScreen(),
                        ),
                      ),
                      icon: const Icon(Icons.map_outlined, size: 20),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(child: _buildHomeTabs()),
            if (_homeTab == 0) ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 0, 22, 14),
                  child: TextField(
                    controller: _searchController,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _submitSearch(),
                    decoration: InputDecoration(
                      hintText: 'Lugar, restaurante ou experiência',
                      hintStyle: const TextStyle(
                        color: secondaryColor,
                        fontSize: 13,
                      ),
                      prefixIcon: const Icon(Icons.search, color: textColor),
                      suffixIcon: IconButton(
                        tooltip: 'Pesquisar',
                        onPressed: _submitSearch,
                        icon: const Icon(Icons.arrow_forward, color: textColor),
                      ),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: GunduaTheme.pageInset,
                  ),
                  child: DiscoveryBanner(onExplore: widget.onGoExplore),
                ),
              ),
              SliverToBoxAdapter(
                child: _sectionTitle(
                  'Destaques da Semana',
                  'Uma seleção para a tua próxima saída.',
                ),
              ),
              SliverToBoxAdapter(child: _buildWeeklyHighlights()),
              SliverToBoxAdapter(child: _buildCommunityPlaces()),
              if (!_loadingRecentlyViewed &&
                  _recentlyViewedPlaces.isNotEmpty) ...[
                SliverToBoxAdapter(
                  child: _sectionTitle(
                    'Vistos recentemente',
                    '',
                    action: TextButton(
                      onPressed: _clearRecentlyViewed,
                      child: const Text(
                        'Limpar',
                        style: TextStyle(color: accentColor),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 164,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      scrollDirection: Axis.horizontal,
                      itemCount: _recentlyViewedPlaces.length,
                      separatorBuilder: (_, _) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        final place = _recentlyViewedPlaces[index];
                        final name = (place['name'] ?? 'Destino').toString();
                        final recentPlace = Place.fromMap(place);
                        final location =
                            (place['locality'] ?? place['location'] ?? '')
                                .toString();
                        return SizedBox(
                          width: 150,
                          child: Material(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(18),
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: () => _openPlace(place),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(child: _placeImage(recentPlace)),
                                  Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          name,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: textColor,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          location,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: secondaryColor,
                                            fontSize: 10,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
              SliverToBoxAdapter(
                child: _sectionTitle(
                  _locationName,
                  '',
                  action: IconButton(
                    tooltip: 'Alterar localização',
                    onPressed: _chooseLocation,
                    icon: const Icon(
                      Icons.my_location_outlined,
                      color: accentColor,
                    ),
                  ),
                ),
              ),
              if (_topPlaces.isEmpty)
                SliverToBoxAdapter(child: _buildLocationMessage())
              else
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 232,
                    child: CarouselView(
                      onTap: (index) => _openPlace(_topPlaces[index].toMap()),
                      itemExtent: 205,
                      shrinkExtent: 185,
                      children: _topPlaces
                          .take(100)
                          .toList()
                          .asMap()
                          .entries
                          .map((entry) => _buildTopCard(entry.value, entry.key))
                          .toList(),
                    ),
                  ),
                ),
              SliverToBoxAdapter(child: _sectionTitle('Top 100 em Lisboa', '')),
              if (_ratedTopPlaces.isEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_loadingRatings)
                          const LinearProgressIndicator(minHeight: 2)
                        else ...[
                          Text(
                            _ratingsError ??
                                'Ainda não há classificações disponíveis.',
                            style: const TextStyle(
                              color: secondaryColor,
                              fontSize: 13,
                            ),
                          ),
                          if (_topPlaces.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            const Text(
                              'Explora mais perto de ti.',
                              style: TextStyle(
                                color: secondaryColor,
                                fontSize: 12,
                              ),
                            ),
                          ],
                          TextButton(
                            onPressed: _loadRatedPlaces,
                            child: const Text('Tentar novamente'),
                          ),
                        ],
                      ],
                    ),
                  ),
                )
              else
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 232,
                    child: CarouselView(
                      onTap: (index) =>
                          _openPlace(_ratedTopPlaces[index].toMap()),
                      itemExtent: 205,
                      shrinkExtent: 185,
                      children: _ratedTopPlaces
                          .asMap()
                          .entries
                          .map((entry) => _buildTopCard(entry.value, entry.key))
                          .toList(),
                    ),
                  ),
                ),
              SliverToBoxAdapter(child: _sectionTitle('Gundua recomenda', '')),
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 270,
                  child: CarouselView(
                    onTap: (index) => _openPlace(_hiddenGems[index].toMap()),
                    itemExtent: 238,
                    shrinkExtent: 210,
                    children: _hiddenGems.map(_buildGemCard).toList(),
                  ),
                ),
              ),
            ],
            if (_homeTab == 1)
              SliverToBoxAdapter(
                child: FriendsFeed(
                  refreshToken: widget.refreshToken,
                  onOpenPlace: _openPlace,
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 138)),
          ],
        ),
      ),
    );
  }
}
