import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/community_activity.dart';
import '../models/place.dart';
import '../services/explorer_matching_service.dart';
import '../services/favorites_service.dart';
import '../services/friends_demo_data.dart';
import '../services/location_service.dart';
import '../services/visited_places_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/place_category_badge.dart';
import 'place_details_screen.dart';

class FriendsFeed extends StatefulWidget {
  const FriendsFeed({super.key, this.refreshToken = 0, this.onOpenPlace});

  final int refreshToken;
  final Future<void> Function(Map<String, dynamic> place)? onOpenPlace;

  @override
  State<FriendsFeed> createState() => _FriendsFeedState();
}

class _FriendsFeedState extends State<FriendsFeed> {
  static const _likesKey = 'gundua_friend_activity_likes';
  static const _followingKey = 'gundua_followed_explorers';

  final _favoritesService = FavoritesService();
  final _matcher = ExplorerMatchingService();
  final _preferences = SharedPreferences.getInstance();
  final _location = LocationPreferenceService.selection;

  List<Map<String, dynamic>> _favorites = [];
  List<Map<String, dynamic>> _visits = [];
  Set<String> _likedIds = {};
  Set<String> _followingIds = {};
  bool _canSaveFavorite = false;
  bool _reactionsReady = false;
  bool _savingReaction = false;
  bool _savingFavorite = false;
  int _historyRequest = 0;
  int _favoriteRevision = 0;

  @override
  void initState() {
    super.initState();
    _location.addListener(_refreshLocation);
    _restoreLocation();
    _loadReactions();
    _refreshHistory();
  }

  @override
  void didUpdateWidget(covariant FriendsFeed oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshToken != oldWidget.refreshToken) _refreshHistory();
  }

  @override
  void dispose() {
    _location.removeListener(_refreshLocation);
    super.dispose();
  }

  void _refreshLocation() => setState(() {});

  Future<void> _restoreLocation() async {
    if (_location.value != null) return;
    try {
      await LocationPreferenceService().getSelected();
    } catch (error) {
      debugPrint('Não foi possível restaurar a localização: $error');
    }
  }

  Future<void> _loadReactions() async {
    try {
      final prefs = await _preferences;
      if (!mounted) return;
      setState(() {
        _likedIds = prefs.getStringList(_likesKey)?.toSet() ?? {};
        _followingIds = prefs.getStringList(_followingKey)?.toSet() ?? {};
        _reactionsReady = true;
      });
    } catch (error) {
      debugPrint('Não foi possível carregar as interações: $error');
    }
  }

  Future<List<Map<String, dynamic>>?> _readPlaces(
    Future<List<Map<String, dynamic>>> Function() read,
  ) async {
    try {
      return await read();
    } catch (error) {
      debugPrint('Não foi possível carregar a atividade de exploração: $error');
      return null;
    }
  }

  Future<void> _refreshHistory() async {
    final request = ++_historyRequest;
    final favoriteRevision = _favoriteRevision;
    final (favorites, visits) = await (
      _readPlaces(_favoritesService.getFavorites),
      _readPlaces(VisitedPlacesService().getVisitedPlaces),
    ).wait;
    if (!mounted || request != _historyRequest) return;
    setState(() {
      if (favorites != null && favoriteRevision == _favoriteRevision) {
        _favorites = favorites;
      }
      _visits = visits ?? _visits;
      _canSaveFavorite = true;
    });
  }

  Future<void> _toggleReaction(String id, {required bool follow}) async {
    if (!_reactionsReady || _savingReaction) return;
    final ids = Set<String>.of(follow ? _followingIds : _likedIds);
    if (!ids.add(id)) ids.remove(id);

    setState(() => _savingReaction = true);
    try {
      final prefs = await _preferences;
      final key = follow ? _followingKey : _likesKey;
      if (!await prefs.setStringList(key, ids.toList())) {
        throw StateError('Não foi possível guardar a interação.');
      }
      if (!mounted) return;
      setState(() {
        if (follow) {
          _followingIds = ids;
        } else {
          _likedIds = ids;
        }
      });
    } catch (_) {
      _showError('Não foi possível guardar a interação.');
    } finally {
      if (mounted) setState(() => _savingReaction = false);
    }
  }

  Future<void> _toggleFavorite(Map<String, dynamic> place) async {
    if (_savingFavorite || !_canSaveFavorite) return;
    setState(() => _savingFavorite = true);
    try {
      final saved = await _favoritesService.toggleFavorite(place);
      if (!mounted) return;
      final id = _favoritesService.getPlaceId(place);
      // An earlier refresh may still contain the old favorite state.
      _favoriteRevision++;
      setState(() {
        _favorites = [
          ..._favorites.where(
            (item) => _favoritesService.getPlaceId(item) != id,
          ),
          if (saved) place,
        ];
      });
    } catch (_) {
      _showError('Não foi possível atualizar os favoritos.');
    } finally {
      if (mounted) setState(() => _savingFavorite = false);
    }
  }

  Future<void> _openPlace(Map<String, dynamic> place) async {
    final openPlace = widget.onOpenPlace;
    if (openPlace != null) {
      await openPlace(place);
    } else {
      await Navigator.of(context).push<void>(
        MaterialPageRoute(builder: (_) => PlaceDetailsScreen(place: place)),
      );
    }
    if (mounted) await _refreshHistory();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Widget _activityCard(CommunityActivity activity) {
    final favoriteId = _favoritesService.getPlaceId(activity.place);
    return _ActivityCard(
      activity: activity,
      liked: _likedIds.contains(activity.id),
      saved: _favorites.any(
        (item) => _favoritesService.getPlaceId(item) == favoriteId,
      ),
      onLike: _reactionsReady && !_savingReaction
          ? () => _toggleReaction(activity.id, follow: false)
          : null,
      onSave: _canSaveFavorite && !_savingFavorite
          ? () => _toggleFavorite(activity.place)
          : null,
      onOpen: () => _openPlace(activity.place),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final activities = FriendsDemoData.activities;
    final matches = _matcher.rank(
      explorers: FriendsDemoData.explorers,
      visits: _visits,
      favorites: _favorites,
      location: _location.value,
    );
    final hasHistory =
        _visits.isNotEmpty || _favorites.isNotEmpty || _location.value != null;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 720),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: GunduaTheme.pageInset,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Atividade dos amigos', style: text.headlineMedium),
              const SizedBox(height: 4),
              Text('Atividade de exemplo', style: text.bodySmall),
              const SizedBox(height: 16),
              _activityCard(activities.first),
              const SizedBox(height: 28),
              Text('Exploradores sugeridos', style: text.titleLarge),
              const SizedBox(height: 5),
              Text(
                hasHistory
                    ? 'Afinidade estimada a partir das tuas visitas, favoritos e localização.'
                    : 'Estimativa inicial. Guarda locais, marca visitas ou escolhe uma localização para a personalizar.',
                style: text.bodySmall,
              ),
              const SizedBox(height: 12),
              LayoutBuilder(
                builder: (context, constraints) {
                  final width = constraints.maxWidth >= 620
                      ? (constraints.maxWidth - 24) / matches.length
                      : 190.0;
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: 12,
                      children: [
                        for (final match in matches)
                          SizedBox(
                            width: width,
                            child: _ExplorerCard(
                              match: match,
                              following: _followingIds.contains(
                                match.explorer.id,
                              ),
                              onFollow: _reactionsReady && !_savingReaction
                                  ? () => _toggleReaction(
                                      match.explorer.id,
                                      follow: true,
                                    )
                                  : null,
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 28),
              for (final activity in activities.skip(1)) ...[
                _activityCard(activity),
                const SizedBox(height: 12),
              ],
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (_) => _PhotoCredits(activities: activities),
                  ),
                  child: const Text('Créditos das fotografias'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.liked,
    required this.saved,
    required this.onLike,
    required this.onSave,
    required this.onOpen,
  });

  final CommunityActivity activity;
  final bool liked;
  final bool saved;
  final VoidCallback? onLike;
  final VoidCallback? onSave;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final place = Place.fromMap(activity.place);
    final icon = switch (activity.kind) {
      ActivityKind.saved => Icons.bookmark_border_rounded,
      ActivityKind.added => Icons.add_location_alt_outlined,
      ActivityKind.checkIn => Icons.location_on_outlined,
    };

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(
              children: [
                _ExplorerAvatar(explorer: activity.explorer),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(activity.explorer.name, style: text.titleMedium),
                      Text(
                        '${activity.kind.label} · ${activity.time}',
                        style: text.bodySmall,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(icon, color: GunduaTheme.accent, size: 21),
              ],
            ),
          ),
          InkWell(
            onTap: onOpen,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (activity.photo case final photo?)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: AspectRatio(
                        aspectRatio: 2.4,
                        child: Image.asset(
                          photo.asset,
                          fit: BoxFit.cover,
                          excludeFromSemantics: true,
                          errorBuilder: (_, _, _) => const ColoredBox(
                            color: GunduaTheme.moss,
                            child: Icon(
                              Icons.place_outlined,
                              color: GunduaTheme.accent,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 11),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            PlaceCategoryBadge(category: place.category),
                            const SizedBox(height: 6),
                            Text(place.name, style: text.titleLarge),
                            Text(
                              place.locality ?? place.address,
                              style: text.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(
                        Icons.arrow_outward_rounded,
                        color: GunduaTheme.accent,
                        size: 21,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            child: Wrap(
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Semantics(
                  toggled: liked,
                  child: Tooltip(
                    message: liked ? 'Retirar gosto' : 'Gostar da atividade',
                    child: TextButton.icon(
                      onPressed: onLike,
                      icon: Icon(
                        liked
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        size: 20,
                      ),
                      label: Text('${activity.likes + (liked ? 1 : 0)}'),
                      style: TextButton.styleFrom(
                        foregroundColor: GunduaTheme.terracotta,
                      ),
                    ),
                  ),
                ),
                Semantics(
                  toggled: saved,
                  child: TextButton.icon(
                    onPressed: onSave,
                    icon: Icon(
                      saved
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      size: 20,
                    ),
                    label: Text(saved ? 'Guardado' : 'Guardar'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ExplorerCard extends StatelessWidget {
  const _ExplorerCard({
    required this.match,
    required this.following,
    required this.onFollow,
  });

  final ExplorerMatch match;
  final bool following;
  final VoidCallback? onFollow;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final explorer = match.explorer;
    final button = following
        ? OutlinedButton(onPressed: onFollow, child: const Text('A seguir'))
        : FilledButton(onPressed: onFollow, child: const Text('Seguir'));

    return Card(
      margin: EdgeInsets.zero,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [GunduaTheme.moss, GunduaTheme.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(GunduaTheme.cardRadius),
        ),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _ExplorerAvatar(explorer: explorer),
              const SizedBox(height: 8),
              Text(explorer.name, style: text.titleMedium),
              Text(explorer.area, style: text.bodySmall),
              const SizedBox(height: 7),
              Text(
                '${match.percent}% de afinidade',
                style: text.bodySmall?.copyWith(
                  color: GunduaTheme.forest,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: Semantics(toggled: following, child: button),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExplorerAvatar extends StatelessWidget {
  const _ExplorerAvatar({required this.explorer});

  final Explorer explorer;

  @override
  Widget build(BuildContext context) {
    final initials = explorer.name
        .split(' ')
        .where((word) => word.isNotEmpty)
        .take(2)
        .map((word) => word[0])
        .join();
    final (background, foreground) = switch (explorer.id) {
      'demo-ines' => (GunduaTheme.moss, GunduaTheme.forest),
      'demo-tiago' => (GunduaTheme.cream, GunduaTheme.ink),
      _ => (GunduaTheme.clay, GunduaTheme.terracotta),
    };
    return ExcludeSemantics(
      child: CircleAvatar(
        radius: 20,
        backgroundColor: background,
        foregroundColor: foreground,
        child: Text(
          initials,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _PhotoCredits extends StatelessWidget {
  const _PhotoCredits({required this.activities});

  final Iterable<CommunityActivity> activities;

  Future<void> _openLink(BuildContext context, Uri uri) async {
    if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir a ligação.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      scrollable: true,
      title: const Text('Créditos das fotografias'),
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Imagens do Wikimedia Commons redimensionadas e convertidas para WebP.',
          ),
          const SizedBox(height: 8),
          for (final activity in activities)
            if (activity.photo case final photo?) ...[
              TextButton(
                onPressed: () => _openLink(
                  context,
                  Uri.https(
                    'commons.wikimedia.org',
                    '/wiki/File:${photo.commonsFile}',
                  ),
                ),
                child: Text(activity.place['name'].toString()),
              ),
              Text('${photo.author} · ${photo.license}'),
            ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => _openLink(
            context,
            Uri.https('creativecommons.org', '/licenses/by-sa/4.0/'),
          ),
          child: const Text('Licença CC BY-SA 4.0'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Fechar'),
        ),
      ],
    );
  }
}
