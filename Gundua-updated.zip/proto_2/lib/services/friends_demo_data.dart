import '../models/community_activity.dart';
import 'curated_places_service.dart';

abstract final class FriendsDemoData {
  static final _places = {
    for (final place in CuratedPlacesService.lisbonHiddenGems)
      place['placeId']: place,
  };

  static Map<String, dynamic> _place(String id) =>
      _places['lisbon-hidden-$id']!;

  static String _photo(String id) =>
      CuratedPlacesService.photoAssets['lisbon-hidden-$id']!;

  static final _ines = Explorer(
    id: 'demo-ines',
    name: 'Inês Matos',
    area: 'Arroios, Lisboa',
    latitude: 38.7290,
    longitude: -9.1333,
    visits: [_place('estufa-fria'), _place('torel'), _place('marioneta')],
    favorites: [_place('estufa-fria'), _place('torel')],
  );

  static final _tiago = Explorer(
    id: 'demo-tiago',
    name: 'Tiago Costa',
    area: 'Graça, Lisboa',
    latitude: 38.7169,
    longitude: -9.1329,
    visits: [_place('feira-ladra'), _place('monte-agudo'), _place('mae-dagua')],
    favorites: [_place('feira-ladra'), _place('monte-agudo')],
  );

  static final _marta = Explorer(
    id: 'demo-marta',
    name: 'Marta Lopes',
    area: 'Santos, Lisboa',
    latitude: 38.7065,
    longitude: -9.1559,
    visits: [_place('marioneta'), _place('bordalo'), _place('casa-alentejo')],
    favorites: [_place('marioneta'), _place('casa-alentejo')],
  );

  static final explorers = List<Explorer>.unmodifiable([_ines, _tiago, _marta]);

  static final activities = List<CommunityActivity>.unmodifiable([
    CommunityActivity(
      id: 'demo-estufa-fria',
      explorer: _ines,
      kind: ActivityKind.saved,
      place: _place('estufa-fria'),
      time: 'Há 2 h',
      likes: 12,
      photo: (
        asset: _photo('estufa-fria'),
        author: '0000ff',
        license: 'CC BY-SA 4.0',
        commonsFile: 'Estufa-Fria-Lisboa-2017.jpg',
      ),
    ),
    CommunityActivity(
      id: 'demo-feira-ladra',
      explorer: _tiago,
      kind: ActivityKind.added,
      place: _place('feira-ladra'),
      time: 'Ontem',
      likes: 8,
      photo: (
        asset: _photo('feira-ladra'),
        author: 'Carlos Luis M C da Cruz',
        license: 'Domínio público',
        commonsFile: 'Feira_da_ladra.jpg',
      ),
    ),
    CommunityActivity(
      id: 'demo-marioneta',
      explorer: _marta,
      kind: ActivityKind.checkIn,
      place: _place('marioneta'),
      time: 'Ontem',
      likes: 16,
      photo: (
        asset: _photo('marioneta'),
        author: 'GualdimG',
        license: 'CC BY-SA 4.0',
        commonsFile: 'Museu_da_Marioneta_(Lisboa)_01.jpg',
      ),
    ),
  ]);
}
