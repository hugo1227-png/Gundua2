import 'package:flutter/material.dart';

/// GUNDUA's single source of truth for colour, type, spacing and corner radii.
/// Keep display and interaction styles here instead of duplicating per screen.
abstract final class GunduaTheme {
  static const ink = Color(0xFF222D26);
  static const muted = Color(0xFF58655C);
  static const accent = Color(0xFF25584A);
  static const forest = Color(0xFF143C32);
  static const moss = Color(0xFFDFEBE1);
  static const terracotta = Color(0xFFA0432F);
  static const clay = Color(0xFFF6E4D9);
  static const cream = Color(0xFFF3EBDE);
  static const canvas = Color(0xFFF9F8F6);
  static const surface = Color(0xFFFFFDFA);
  static const line = Color(0xFFE5DED3);
  static const image = Color(0xFFE9E8DF);
  static const sunlight = Color(0xFFF4AC7F);

  static const forestGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [forest, accent],
  );

  static const double spaceXs = 4;
  static const double spaceSm = 8;
  static const double spaceMd = 12;
  static const double spaceLg = 16;
  static const double spaceXl = 24;
  static const double spaceXxl = 32;

  static const double pageInset = 22;
  static const double cardRadius = 18;
  // For cards padded by 12 px: inner radius = 18 - 12 = 6 px.
  static const double innerRadius = 6;
  static const double sectionGap = 28;

  static const tabularNumbers = TextStyle(
    fontFeatures: [FontFeature.tabularFigures()],
  );

  static ThemeData light() {
    final colors = ColorScheme.fromSeed(
      seedColor: accent,
      primary: accent,
      onPrimary: Colors.white,
      primaryContainer: moss,
      onPrimaryContainer: forest,
      secondary: terracotta,
      onSecondary: Colors.white,
      secondaryContainer: clay,
      onSecondaryContainer: terracotta,
      surface: surface,
      onSurface: ink,
      onSurfaceVariant: muted,
      surfaceContainerLow: canvas,
      surfaceContainer: cream,
      outlineVariant: line,
      brightness: Brightness.light,
    );
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(14),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: colors,
      fontFamily: 'DM Sans',
      scaffoldBackgroundColor: canvas,
      iconTheme: const IconThemeData(color: ink, size: 22),
      appBarTheme: const AppBarTheme(
        backgroundColor: canvas,
        foregroundColor: ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(cardRadius),
          side: const BorderSide(color: line),
        ),
      ),
      dividerTheme: const DividerThemeData(color: line),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: accent,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 32,
          height: 1.13,
          fontWeight: FontWeight.w700,
          letterSpacing: -.8,
          color: ink,
        ),
        headlineMedium: TextStyle(
          fontSize: 28,
          height: 1.18,
          fontWeight: FontWeight.w700,
          letterSpacing: -.5,
          color: ink,
        ),
        titleLarge: TextStyle(
          fontSize: 21,
          height: 1.2,
          fontWeight: FontWeight.w700,
          color: ink,
        ),
        titleMedium: TextStyle(
          fontSize: 16,
          height: 1.3,
          fontWeight: FontWeight.w600,
          color: ink,
        ),
        bodyLarge: TextStyle(fontSize: 16, height: 1.45, color: ink),
        bodyMedium: TextStyle(fontSize: 14, height: 1.45, color: ink),
        bodySmall: TextStyle(fontSize: 12, height: 1.4, color: muted),
        labelLarge: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: ink,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        prefixIconColor: muted,
        suffixIconColor: muted,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: accent, width: 1.5),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: surface,
        selectedColor: moss,
        side: const BorderSide(color: line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        labelStyle: const TextStyle(
          fontSize: 13,
          color: ink,
          fontWeight: FontWeight.w600,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: accent,
          foregroundColor: Colors.white,
          minimumSize: const Size(100, 48),
          shape: shape,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: ink,
          side: const BorderSide(color: line),
          minimumSize: const Size(100, 48),
          shape: shape,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: accent),
      ),
    );
  }
}
