import 'package:flutter/material.dart';

import '../theme/gundua_theme.dart';

String placeDistanceLabel(double meters) => meters < 1000
    ? '${meters.round()}\u00A0m'
    : '${(meters / 1000).toStringAsFixed(1)}\u00A0km';

class PlaceRating extends StatelessWidget {
  const PlaceRating(this.rating, {super.key, this.reviewCount});

  final double rating;
  final int? reviewCount;

  @override
  Widget build(BuildContext context) {
    final count = reviewCount;
    final score = rating.toStringAsFixed(1);
    return Semantics(
      label: count == null
          ? 'Avaliação: $score'
          : 'Avaliação: $score, $count avaliações',
      excludeSemantics: true,
      child: Wrap(
        spacing: GunduaTheme.spaceXs,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const Icon(Icons.star_rounded, size: 16, color: GunduaTheme.rating),
          Text(
            count == null ? score : '$score ($count)',
            style: Theme.of(context).textTheme.bodySmall
                ?.merge(GunduaTheme.tabularNumbers)
                .copyWith(color: GunduaTheme.ink, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
