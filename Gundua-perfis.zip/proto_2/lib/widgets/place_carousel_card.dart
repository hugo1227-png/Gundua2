import 'package:flutter/material.dart';

import '../models/place.dart';
import '../theme/gundua_theme.dart';
import 'place_category_badge.dart';
import 'place_favorite_button.dart';
import 'place_metadata.dart';
import 'place_result_tile.dart';
import 'place_photo.dart';

/// Cartão compacto para coleções editoriais; resultados de pesquisa usam
/// PlaceResultTile em lista vertical para melhor leitura dos dados.
class PlaceCarouselCard extends StatelessWidget {
  const PlaceCarouselCard({
    super.key,
    required this.place,
    required this.onTap,
    required this.onFavorite,
    required this.isFavorite,
    this.imageFuture,
    this.favoriteBusy = false,
  });

  final Place place;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final bool isFavorite;
  final bool favoriteBusy;
  final Future<String?>? imageFuture;

  @override
  Widget build(BuildContext context) {
    final styles = Theme.of(context).textTheme;
    final distance = place.distanceMeters;
    final rating = place.rating;
    final category = PlaceResultTile.categoryName(place.category);
    final locality = place.locality?.isNotEmpty == true
        ? place.locality!
        : place.address;
    final hasPhoto =
        place.imageUrl?.trim().isNotEmpty == true || imageFuture != null;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (hasPhoto)
                  Expanded(
                    child: PlacePhoto(
                      url: place.imageUrl,
                      imageFuture: imageFuture,
                    ),
                  ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(
                    GunduaTheme.spaceMd,
                    GunduaTheme.spaceMd,
                    hasPhoto ? GunduaTheme.spaceMd : 52,
                    GunduaTheme.spaceMd,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    spacing: GunduaTheme.spaceXs,
                    children: [
                      Text(
                        place.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: styles.titleMedium,
                      ),
                      if (category != 'Ponto de interesse')
                        PlaceCategoryBadge(category: category),
                      if (locality.isNotEmpty)
                        Text(
                          locality,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: styles.bodySmall,
                        ),
                      if (rating != null || distance != null)
                        Wrap(
                          spacing: GunduaTheme.spaceMd,
                          runSpacing: GunduaTheme.spaceXs,
                          children: [
                            if (rating != null) PlaceRating(rating),
                            if (distance != null)
                              Text(
                                placeDistanceLabel(distance),
                                style: styles.bodySmall?.merge(
                                  GunduaTheme.tabularNumbers,
                                ),
                              ),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
            PositionedDirectional(
              top: GunduaTheme.spaceXs,
              end: GunduaTheme.spaceXs,
              child: Material(
                color: GunduaTheme.surface,
                shape: const CircleBorder(),
                child: PlaceFavoriteButton(
                  isFavorite: isFavorite,
                  busy: favoriteBusy,
                  onPressed: onFavorite,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
