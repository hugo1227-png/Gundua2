import 'package:flutter/material.dart';

import '../services/community_places_service.dart';
import '../theme/gundua_theme.dart';

/// Displays a real place photo when available; never substitutes a fake image.
class PlacePhoto extends StatelessWidget {
  const PlacePhoto({super.key, this.url, this.imageFuture});
  final String? url;
  final Future<String?>? imageFuture;

  @override
  Widget build(BuildContext context) {
    final reference = url;
    if (reference != null && reference.isNotEmpty) {
      if (CommunityPlacesService.isLocalPhoto(reference)) {
        return _localPhoto(reference);
      }
      return _network(reference);
    }
    if (imageFuture == null) return const ColoredBox(color: GunduaTheme.image);
    return FutureBuilder<String?>(
      future: imageFuture,
      builder: (context, snapshot) {
        final imageUrl = snapshot.data;
        if (imageUrl?.isNotEmpty == true) return _network(imageUrl!);
        return ColoredBox(
          color: GunduaTheme.image,
          child: snapshot.connectionState == ConnectionState.waiting
              ? const Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                )
              : const SizedBox.expand(),
        );
      },
    );
  }

  Widget _localPhoto(String reference) {
    final service = CommunityPlacesService.instance;
    return FutureBuilder<void>(
      future: service.load(),
      builder: (context, snapshot) {
        final bytes = service.photo(reference);
        if (bytes == null) return const ColoredBox(color: GunduaTheme.image);
        return Image.memory(
          bytes,
          width: double.infinity,
          height: double.infinity,
          fit: BoxFit.cover,
          errorBuilder: (_, _, _) => const ColoredBox(color: GunduaTheme.image),
        );
      },
    );
  }

  Widget _network(String imageUrl) => Image.network(
    imageUrl,
    fit: BoxFit.cover,
    loadingBuilder: (context, child, progress) => progress == null
        ? child
        : const ColoredBox(
            color: GunduaTheme.image,
            child: Center(
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
          ),
    errorBuilder: (context, error, stackTrace) =>
        const ColoredBox(color: GunduaTheme.image),
  );
}
