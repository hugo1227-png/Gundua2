import 'package:flutter/material.dart';

import '../models/place.dart';
import '../theme/gundua_theme.dart';
import 'place_category_badge.dart';
import 'place_photo.dart';

class DiscoveryBanner extends StatelessWidget {
  const DiscoveryBanner({super.key, required this.onExplore});

  final VoidCallback? onExplore;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: DecoratedBox(
        decoration: const BoxDecoration(color: GunduaTheme.forest),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/lisbon_discovery.webp',
                alignment: Alignment.centerRight,
                fit: BoxFit.cover,
                excludeFromSemantics: true,
                errorBuilder: (_, _, _) => const SizedBox.shrink(),
              ),
            ),
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF122C25),
                      Color(0xF218352C),
                      Color(0xA618352C),
                      Color(0x3018352C),
                    ],
                    stops: [0, .36, .76, 1],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(GunduaTheme.spaceXl),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 285),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Lugares e experiências na tua cidade',
                      style: text.headlineMedium?.copyWith(color: Colors.white),
                    ),
                    const SizedBox(height: GunduaTheme.spaceSm),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 245),
                      child: Text(
                        'Descobre lugares autênticos e recantos recomendados pela Gundua.',
                        style: text.bodyMedium?.copyWith(color: Colors.white),
                      ),
                    ),
                    if (onExplore != null) ...[
                      const SizedBox(height: GunduaTheme.spaceLg),
                      FilledButton.icon(
                        onPressed: onExplore,
                        style: FilledButton.styleFrom(
                          backgroundColor: GunduaTheme.cream,
                          foregroundColor: GunduaTheme.forest,
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                        ),
                        icon: const Icon(Icons.explore_outlined, size: 18),
                        label: const Text('Explorar locais'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WeeklyHighlightCard extends StatelessWidget {
  const WeeklyHighlightCard({
    super.key,
    required this.place,
    required this.note,
    required this.onOpen,
    this.photoAsset,
    this.imageFuture,
  });

  final Place place;
  final String note;
  final VoidCallback onOpen;
  final String? photoAsset;
  final Future<String?>? imageFuture;
  static const _padding = GunduaTheme.spaceMd;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Material(
      borderRadius: BorderRadius.circular(GunduaTheme.cardRadius),
      clipBehavior: Clip.antiAlias,
      child: Ink(
        decoration: BoxDecoration(
          color: GunduaTheme.surface,
          borderRadius: BorderRadius.circular(GunduaTheme.cardRadius),
          border: Border.all(color: GunduaTheme.line),
        ),
        child: InkWell(
          onTap: onOpen,
          child: Padding(
            padding: const EdgeInsets.all(_padding),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(
                    GunduaTheme.nestedRadius(GunduaTheme.cardRadius, _padding),
                  ),
                  child: SizedBox(
                    width: 72,
                    height: 84,
                    child: photoAsset == null
                        ? PlacePhoto(
                            url: place.imageUrl,
                            imageFuture: imageFuture,
                          )
                        : Image.asset(
                            photoAsset!,
                            fit: BoxFit.cover,
                            excludeFromSemantics: true,
                          ),
                  ),
                ),
                const SizedBox(width: GunduaTheme.spaceMd),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        place.name,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: text.titleMedium,
                      ),
                      const SizedBox(height: GunduaTheme.spaceXs),
                      Text(
                        note,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: text.bodySmall,
                      ),
                      const SizedBox(height: GunduaTheme.spaceXs),
                      PlaceCategoryBadge(category: place.category),
                    ],
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(left: 4, top: 4),
                  child: Icon(
                    Icons.chevron_right_rounded,
                    size: 17,
                    color: GunduaTheme.accent,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
