import 'package:flutter/material.dart';

import '../theme/gundua_theme.dart';

class PlaceCategoryBadge extends StatelessWidget {
  const PlaceCategoryBadge({super.key, required this.category});

  final String category;

  static final _food = RegExp(
    'restaur|catering|caf[eé]|coffee|mercado',
    caseSensitive: false,
  );
  static final _outdoors = RegExp(
    'natur|par[kq]|garden|jardim|miradouro|viewpoint',
    caseSensitive: false,
  );
  static final _culture = RegExp(
    'muse|cultur|historic|históric|patrim[oó]|monument|teatr',
    caseSensitive: false,
  );
  static final _water = RegExp('beach|praia', caseSensitive: false);

  @override
  Widget build(BuildContext context) {
    final (icon, foreground, background) = switch (category) {
      final label when _food.hasMatch(label) => (
        Icons.restaurant_outlined,
        GunduaTheme.terracotta,
        GunduaTheme.clay,
      ),
      final label when _outdoors.hasMatch(label) => (
        Icons.park_outlined,
        GunduaTheme.accent,
        GunduaTheme.moss,
      ),
      final label when _culture.hasMatch(label) => (
        Icons.account_balance_outlined,
        const Color(0xFF6C502D),
        const Color(0xFFF4E8CF),
      ),
      final label when _water.hasMatch(label) => (
        Icons.water_outlined,
        const Color(0xFF365E66),
        const Color(0xFFE0EDF0),
      ),
      _ => (Icons.place_outlined, GunduaTheme.forest, GunduaTheme.cream),
    };

    return DecoratedBox(
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: foreground, size: 13),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                category,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: foreground,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  height: 1.1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
