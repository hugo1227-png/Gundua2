import 'package:flutter/material.dart';

import '../models/community_activity.dart';

class ExplorerAvatar extends StatelessWidget {
  const ExplorerAvatar({super.key, required this.explorer, required this.size});

  final Explorer explorer;
  final double size;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final initials = explorer.name.characters
        .split(' '.characters)
        .where((word) => word.isNotEmpty)
        .take(2)
        .map((word) => word.first)
        .join();
    final asset = explorer.avatarAsset;
    return CircleAvatar(
      radius: size / 2,
      backgroundColor: theme.colorScheme.primaryContainer,
      foregroundColor: theme.colorScheme.onPrimaryContainer,
      foregroundImage: asset == null ? null : AssetImage(asset),
      onForegroundImageError: asset == null ? null : (_, _) {},
      child: ExcludeSemantics(
        child: Text(initials, style: TextStyle(fontSize: size * .32)),
      ),
    );
  }
}
