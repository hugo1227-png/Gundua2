import 'package:flutter/material.dart';

import '../models/place.dart';
import '../theme/gundua_theme.dart';
import 'place_category_badge.dart';
import 'place_favorite_button.dart';
import 'place_metadata.dart';
import 'place_photo.dart';

/// One reusable category-aware result, used in Explore and Favorites.
class PlaceResultTile extends StatelessWidget {
  const PlaceResultTile({
    super.key,
    required this.place,
    required this.onTap,
    required this.onFavorite,
    required this.isFavorite,
    this.imageFuture,
    this.favoriteBusy = false,
  });

  final Place place;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final bool isFavorite;
  final bool favoriteBusy;
  final Future<String?>? imageFuture;

  static String categoryName(String category) {
    final value = category.toLowerCase();
    if (value.contains('restaurant') || value.contains('catering')) {
      return 'Restaurante';
    }
    if (value.contains('museum') || value.contains('museu')) {
      return 'Museu';
    }
    if (value.contains('monument') ||
        value.contains('heritage') ||
        value.contains('historic')) {
      return 'Monumento';
    }
    if (value.contains('park') ||
        value.contains('garden') ||
        value.contains('natural')) {
      return 'Natureza';
    }
    if (value.contains('beach') || value.contains('praia')) {
      return 'Praia';
    }
    if (value.contains('culture') || value.contains('theatre')) {
      return 'Cultura';
    }
    if (value.contains('square') || value.contains('praça')) {
      return 'Praça';
    }
    if (value == 'ponto de interesse' || value.isEmpty) {
      return 'Ponto de interesse';
    }
    return category.replaceAll('_', ' ').split('.').last;
  }

  String? get _hours {
    final hours = place.openingHours;
    if (hours is String && hours.trim().isNotEmpty) {
      return hours;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final styles = Theme.of(context).textTheme;
    final category = categoryName(place.category);
    final locality = place.locality?.trim().isNotEmpty == true
        ? place.locality!
        : place.address;
    final distance = place.distanceMeters;
    final rating = place.rating;
    final hasPhoto =
        place.imageUrl?.trim().isNotEmpty == true || imageFuture != null;
    final details = [
      if (locality.isNotEmpty) locality,
      if (category == 'Restaurante') ...[
        if (place.cuisine?.isNotEmpty == true) place.cuisine!,
        if (place.priceRange?.isNotEmpty == true) place.priceRange!,
      ],
      if (category == 'Museu' && place.admission?.isNotEmpty == true)
        'Entrada: ${place.admission}',
      if (place.description?.isNotEmpty == true) place.description!,
      ?_hours,
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final photoWidth = (constraints.maxWidth * .29).clamp(0.0, 112.0);
        return Card(
          margin: EdgeInsets.zero,
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(GunduaTheme.spaceMd),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (hasPhoto) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                        GunduaTheme.nestedRadius(
                          GunduaTheme.cardRadius,
                          GunduaTheme.spaceMd,
                        ),
                      ),
                      child: SizedBox(
                        width: photoWidth,
                        height: photoWidth * 1.1,
                        child: PlacePhoto(
                          url: place.imageUrl,
                          imageFuture: imageFuture,
                        ),
                      ),
                    ),
                    const SizedBox(width: GunduaTheme.spaceMd),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: GunduaTheme.spaceXs,
                      children: [
                        Text(place.name, style: styles.titleMedium),
                        if (category != 'Ponto de interesse')
                          PlaceCategoryBadge(category: category),
                        for (final detail in details)
                          Text(
                            detail,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: styles.bodySmall,
                          ),
                        if (rating != null)
                          PlaceRating(rating, reviewCount: place.reviewCount),
                        if (distance != null)
                          Text(
                            placeDistanceLabel(distance),
                            style: styles.bodySmall
                                ?.merge(GunduaTheme.tabularNumbers)
                                .copyWith(
                                  color: GunduaTheme.ink,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                      ],
                    ),
                  ),
                  PlaceFavoriteButton(
                    isFavorite: isFavorite,
                    busy: favoriteBusy,
                    onPressed: onFavorite,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
