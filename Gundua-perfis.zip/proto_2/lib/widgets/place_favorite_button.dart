import 'package:flutter/material.dart';

import '../theme/gundua_theme.dart';

class PlaceFavoriteButton extends StatelessWidget {
  const PlaceFavoriteButton({
    super.key,
    required this.isFavorite,
    required this.onPressed,
    this.busy = false,
  });

  final bool isFavorite;
  final VoidCallback onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: isFavorite,
      child: IconButton(
        tooltip: busy
            ? 'A atualizar favorito'
            : isFavorite
            ? 'Remover dos favoritos'
            : 'Guardar nos favoritos',
        onPressed: busy ? null : onPressed,
        iconSize: 20,
        icon: AnimatedSwitcher(
          duration: MediaQuery.disableAnimationsOf(context)
              ? Duration.zero
              : const Duration(milliseconds: 180),
          child: busy
              ? const SizedBox.square(
                  key: ValueKey('busy'),
                  dimension: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : Icon(
                  isFavorite
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  key: ValueKey(isFavorite),
                  color: isFavorite ? GunduaTheme.accent : GunduaTheme.ink,
                ),
        ),
      ),
    );
  }
}
