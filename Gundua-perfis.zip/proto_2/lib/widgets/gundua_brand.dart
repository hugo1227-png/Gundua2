import 'package:flutter/material.dart';

import '../theme/gundua_theme.dart';

class GunduaBrandMark extends StatelessWidget {
  const GunduaBrandMark({super.key, this.size = 48});

  final double size;

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: SizedBox.square(
        dimension: size,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: GunduaTheme.forestGradient,
            borderRadius: BorderRadius.circular(size * .29),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                'G',
                textScaler: TextScaler.noScaling,
                style: TextStyle(
                  color: GunduaTheme.surface,
                  fontSize: size * .58,
                  fontWeight: FontWeight.w800,
                  height: 1,
                ),
              ),
              Positioned(
                top: size * .12,
                right: size * .12,
                child: Icon(
                  Icons.auto_awesome_rounded,
                  size: size * .22,
                  color: GunduaTheme.sunlight,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GunduaWordmark extends StatelessWidget {
  const GunduaWordmark({
    super.key,
    this.size = 27,
    this.color = GunduaTheme.forest,
  });

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Text(
      'gundua',
      style: TextStyle(
        color: color,
        fontSize: size,
        fontWeight: FontWeight.w800,
        letterSpacing: -size * .045,
        height: 1.1,
      ),
    );
  }
}
