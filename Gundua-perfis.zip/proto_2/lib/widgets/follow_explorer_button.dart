import 'package:flutter/material.dart';

import '../services/explorer_follows.dart';

class FollowExplorerButton extends StatelessWidget {
  const FollowExplorerButton({
    super.key,
    required this.explorerId,
    required this.follows,
  });

  final String explorerId;
  final ExplorerFollows follows;

  Future<void> _toggle(BuildContext context) async {
    try {
      await follows.toggle(explorerId);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Não foi possível atualizar o seguimento.'),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final duration = MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : const Duration(milliseconds: 180);
    return ListenableBuilder(
      listenable: follows,
      builder: (context, _) {
        final following = follows.follows(explorerId);
        final updating = follows.isUpdating(explorerId);
        return Semantics(
          toggled: following,
          child: FilledButton(
            onPressed: follows.isBusy ? null : () => _toggle(context),
            style: FilledButton.styleFrom(
              backgroundColor: following ? colors.primaryContainer : null,
              foregroundColor: following ? colors.onPrimaryContainer : null,
              animationDuration: duration,
            ),
            child: AnimatedSwitcher(
              duration: duration,
              child: updating
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        semanticsLabel: 'A atualizar seguimento',
                      ),
                    )
                  : Text(
                      following ? 'Seguindo' : 'Seguir',
                      key: ValueKey(following),
                    ),
            ),
          ),
        );
      },
    );
  }
}
