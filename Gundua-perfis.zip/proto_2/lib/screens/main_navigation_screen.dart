import 'package:flutter/material.dart';

import '../theme/gundua_theme.dart';
import 'explore_screen.dart';
import 'favorites_screen.dart';
import 'home_screen.dart';
import 'profile_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  static const _navigationGap = GunduaTheme.spaceMd;

  int _selectedIndex = 0;
  int _homeRefreshToken = 0;
  int _favoritesRefreshToken = 0;
  int _exploreRefreshToken = 0;
  String? _homeSearchQuery;
  int _searchRequestToken = 0;

  void _select(int index) {
    if (index == _selectedIndex) return;
    setState(() {
      _selectedIndex = index;
      if (index == 0) _homeRefreshToken++;
      if (index == 2) _favoritesRefreshToken++;
      if (index == 1) _exploreRefreshToken++;
    });
  }

  void _search(String query) {
    setState(() {
      _homeSearchQuery = query;
      _searchRequestToken++;
      _selectedIndex = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(
        refreshToken: _homeRefreshToken,
        onGoExplore: () => _select(1),
        onSearch: _search,
        navigationInset: _BottomNavigation.height + 2 * _navigationGap,
      ),
      ExploreScreen(
        initialQuery: _homeSearchQuery,
        initialQueryToken: _searchRequestToken,
        refreshToken: _exploreRefreshToken,
      ),
      FavoritesScreen(refreshToken: _favoritesRefreshToken),
      const ProfileScreen(),
    ];
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    return Scaffold(
      extendBody: true,
      backgroundColor: GunduaTheme.canvas,
      body: Stack(
        children: [
          Positioned.fill(
            child: IndexedStack(index: _selectedIndex, children: pages),
          ),
          Positioned(
            left: GunduaTheme.pageInset,
            right: GunduaTheme.pageInset,
            bottom: bottom + _navigationGap,
            child: _BottomNavigation(
              currentIndex: _selectedIndex,
              onSelected: _select,
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({
    required this.currentIndex,
    required this.onSelected,
  });

  final int currentIndex;
  final ValueChanged<int> onSelected;

  static const _itemHeight = 56.0;
  static const _radius = 34.0;
  static const height = _itemHeight + 2 * GunduaTheme.spaceSm;

  static const _icons = [
    Icons.home_outlined,
    Icons.explore_outlined,
    Icons.favorite_border,
    Icons.person_outline_rounded,
  ];
  static const _activeIcons = [
    Icons.home_rounded,
    Icons.explore_rounded,
    Icons.favorite_rounded,
    Icons.person_rounded,
  ];
  static const _labels = ['Início', 'Explorar', 'Favoritos', 'Perfil'];

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final innerRadius = BorderRadius.circular(
      GunduaTheme.nestedRadius(_radius, GunduaTheme.spaceSm),
    );
    final duration = MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : const Duration(milliseconds: 200);
    return Material(
      color: colors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(_radius),
        side: BorderSide(color: colors.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(GunduaTheme.spaceSm),
        child: Row(
          children: List.generate(_labels.length, (index) {
            final selected = index == currentIndex;
            final foreground = selected
                ? colors.onPrimaryContainer
                : colors.onSurfaceVariant;
            return Expanded(
              child: Semantics(
                selected: selected,
                child: InkWell(
                  borderRadius: innerRadius,
                  onTap: () => onSelected(index),
                  child: AnimatedContainer(
                    duration: duration,
                    curve: Curves.easeOutCubic,
                    height: _itemHeight,
                    decoration: BoxDecoration(
                      borderRadius: innerRadius,
                      color: selected
                          ? colors.primaryContainer
                          : Colors.transparent,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          selected ? _activeIcons[index] : _icons[index],
                          color: foreground,
                          size: 22,
                        ),
                        const SizedBox(height: GunduaTheme.spaceXs),
                        Flexible(
                          child: Text(
                            _labels[index],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: selected
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                              color: foreground,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
