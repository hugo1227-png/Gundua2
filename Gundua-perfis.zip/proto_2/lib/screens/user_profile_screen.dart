import 'package:flutter/material.dart';

import '../models/community_activity.dart';
import '../models/place.dart';
import '../services/curated_places_service.dart';
import '../services/explorer_follows.dart';
import '../theme/gundua_theme.dart';
import '../widgets/explorer_avatar.dart';
import '../widgets/follow_explorer_button.dart';

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({
    super.key,
    required this.explorer,
    required this.follows,
    required this.onOpenPlace,
    this.activities = const [],
  });

  final Explorer explorer;
  final ExplorerFollows follows;
  final ValueChanged<Map<String, dynamic>> onOpenPlace;
  final List<CommunityActivity> activities;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        top: false,
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(
                GunduaTheme.pageInset,
                GunduaTheme.spaceSm,
                GunduaTheme.pageInset,
                GunduaTheme.spaceXxl,
              ),
              children: [
                Center(
                  child: Semantics(
                    image: true,
                    label: 'Fotografia de ${explorer.name}',
                    child: ExplorerAvatar(explorer: explorer, size: 112),
                  ),
                ),
                const SizedBox(height: GunduaTheme.spaceLg),
                Semantics(
                  header: true,
                  child: Text(
                    explorer.name,
                    textAlign: TextAlign.center,
                    style: text.headlineLarge,
                  ),
                ),
                const SizedBox(height: GunduaTheme.spaceXs),
                Text(
                  explorer.area,
                  textAlign: TextAlign.center,
                  style: text.bodyMedium?.copyWith(color: GunduaTheme.muted),
                ),
                const SizedBox(height: GunduaTheme.spaceXl),
                _ProfileStats(explorer: explorer, follows: follows),
                const SizedBox(height: GunduaTheme.spaceLg),
                FollowExplorerButton(explorerId: explorer.id, follows: follows),
                if (activities.isNotEmpty) ...[
                  const SizedBox(height: GunduaTheme.spaceXxl),
                  const _SectionHeading('Atividade recente'),
                  for (final activity in activities)
                    _ProfilePlaceCard(
                      place: activity.place,
                      caption: '${activity.kind.label} · ${activity.time}',
                      onOpenPlace: onOpenPlace,
                    ),
                ],
                if (explorer.reviews.isNotEmpty) ...[
                  const SizedBox(height: GunduaTheme.spaceXxl),
                  const _SectionHeading('Avaliações'),
                  for (final review in explorer.reviews)
                    _ProfilePlaceCard(
                      place: review.place,
                      caption: review.comment,
                      rating: review.rating,
                      onOpenPlace: onOpenPlace,
                    ),
                ],
                if (explorer.favorites.isNotEmpty) ...[
                  const SizedBox(height: GunduaTheme.spaceXxl),
                  const _SectionHeading('Lugares guardados'),
                  for (final place in explorer.favorites)
                    _ProfilePlaceCard(place: place, onOpenPlace: onOpenPlace),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ProfileStats extends StatelessWidget {
  const _ProfileStats({required this.explorer, required this.follows});

  final Explorer explorer;
  final ExplorerFollows follows;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final text = theme.textTheme;
    final duration = MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : const Duration(milliseconds: 180);

    return ListenableBuilder(
      listenable: follows,
      builder: (context, _) {
        final stats = [
          (
            label: 'Seguidores',
            value:
                explorer.followerCount + (follows.follows(explorer.id) ? 1 : 0),
          ),
          (label: 'A seguir', value: explorer.followingCount),
          (label: 'Avaliações', value: explorer.reviews.length),
        ];
        return DecoratedBox(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            border: Border.all(color: GunduaTheme.line),
            borderRadius: BorderRadius.circular(GunduaTheme.cardRadius),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: GunduaTheme.spaceLg),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final stat in stats)
                  Expanded(
                    child: Column(
                      children: [
                        AnimatedSwitcher(
                          duration: duration,
                          child: Text(
                            '${stat.value}',
                            key: ValueKey(stat.value),
                            textAlign: TextAlign.center,
                            style: text.titleLarge?.merge(
                              GunduaTheme.tabularNumbers,
                            ),
                          ),
                        ),
                        const SizedBox(height: GunduaTheme.spaceXs),
                        Text(
                          stat.label,
                          textAlign: TextAlign.center,
                          style: text.bodySmall,
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading(this.title);

  final String title;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: GunduaTheme.spaceMd),
    child: Semantics(
      header: true,
      child: Text(title, style: Theme.of(context).textTheme.titleLarge),
    ),
  );
}

class _ProfilePlaceCard extends StatelessWidget {
  const _ProfilePlaceCard({
    required this.place,
    required this.onOpenPlace,
    this.caption,
    this.rating,
  });

  final Map<String, dynamic> place;
  final ValueChanged<Map<String, dynamic>> onOpenPlace;
  final String? caption;
  final int? rating;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final item = Place.fromMap(place);
    final photo = CuratedPlacesService.photoAssets[item.id];
    const inset = GunduaTheme.spaceMd;

    return Card(
      margin: const EdgeInsets.only(bottom: GunduaTheme.spaceSm),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => onOpenPlace(place),
        child: Padding(
          padding: const EdgeInsets.all(inset),
          child: Row(
            children: [
              if (photo != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(
                    GunduaTheme.nestedRadius(GunduaTheme.cardRadius, inset),
                  ),
                  child: Image.asset(
                    photo,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    excludeFromSemantics: true,
                  ),
                ),
                const SizedBox(width: GunduaTheme.spaceMd),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.name, style: text.titleMedium),
                    if (rating != null) ...[
                      const SizedBox(height: GunduaTheme.spaceXs),
                      Text(
                        '$rating/5',
                        semanticsLabel: 'Classificação: $rating de 5',
                        style: text.labelLarge
                            ?.copyWith(color: GunduaTheme.accent)
                            .merge(GunduaTheme.tabularNumbers),
                      ),
                    ],
                    const SizedBox(height: GunduaTheme.spaceXs),
                    Text(
                      caption ?? item.locality ?? item.address,
                      style: rating == null
                          ? text.bodySmall?.merge(GunduaTheme.tabularNumbers)
                          : text.bodyMedium,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: GunduaTheme.spaceSm),
              const Icon(
                Icons.chevron_right_rounded,
                color: GunduaTheme.accent,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
