import 'package:flutter/material.dart';

import '../services/local_reviews_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/place_metadata.dart';
import 'place_details_screen.dart';

class MyReviewsScreen extends StatefulWidget {
  const MyReviewsScreen({super.key});

  @override
  State<MyReviewsScreen> createState() => _MyReviewsScreenState();
}

class _MyReviewsScreenState extends State<MyReviewsScreen> {
  final _service = LocalReviewsService();
  List<Map<String, dynamic>> _reviews = [];
  bool _loading = true;
  bool _loadFailed = false;
  String? _deletingId;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    try {
      final reviews = await _service.getReviews();
      if (mounted) setState(() => _reviews = reviews);
    } catch (_) {
      if (mounted) setState(() => _loadFailed = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _open(Map<String, dynamic> review) async {
    final place = review['place'];
    if (place is! Map) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) =>
            PlaceDetailsScreen(place: Map<String, dynamic>.from(place)),
      ),
    );
    if (mounted) await _refresh();
  }

  Future<void> _delete(String id) async {
    if (_deletingId != null) return;
    setState(() => _deletingId = id);
    try {
      await _service.delete(id);
      if (mounted) await _refresh();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível apagar a avaliação.')),
        );
      }
    } finally {
      if (mounted) setState(() => _deletingId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('As tuas avaliações')),
      body: _buildReviews(),
    );
  }

  Widget _buildReviews() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_loadFailed) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Não foi possível carregar as avaliações.'),
            TextButton(
              onPressed: _refresh,
              child: const Text('Tentar novamente'),
            ),
          ],
        ),
      );
    }
    return _reviews.isEmpty
        ? const Center(
            child: Padding(
              padding: EdgeInsets.all(GunduaTheme.spaceXxl),
              child: Text(
                'Ainda não escreveste avaliações. Abre um lugar e toca em “Avaliar este lugar”.',
                textAlign: TextAlign.center,
              ),
            ),
          )
        : ListView.separated(
            padding: const EdgeInsets.symmetric(
              horizontal: GunduaTheme.pageInset,
            ),
            itemCount: _reviews.length,
            separatorBuilder: (_, _) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final review = _reviews[index];
              final place = review['place'];
              final id = (review['placeId'] ?? '').toString();
              final name = place is Map
                  ? (place['name'] ?? 'Lugar').toString()
                  : 'Lugar';
              return ListTile(
                onTap: () => _open(review),
                title: Text(name),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (review['rating'] case final num rating)
                      PlaceRating(rating.toDouble()),
                    Text(
                      (review['comment'] ?? '').toString(),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                trailing: _deletingId == id
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : IconButton(
                        tooltip: 'Apagar avaliação',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: _deletingId == null
                            ? () => _delete(id)
                            : null,
                      ),
              );
            },
          );
  }
}
