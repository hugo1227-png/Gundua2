import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/community_activity.dart';
import '../models/place.dart';
import '../services/explorer_follows.dart';
import '../services/explorer_matching_service.dart';
import '../services/favorites_service.dart';
import '../services/friends_demo_data.dart';
import '../services/location_service.dart';
import '../services/visited_places_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/explorer_avatar.dart';
import '../widgets/follow_explorer_button.dart';
import 'place_details_screen.dart';
import 'user_profile_screen.dart';

class FriendsFeed extends StatefulWidget {
  const FriendsFeed({super.key, this.refreshToken = 0, this.onOpenPlace});

  final int refreshToken;
  final Future<void> Function(Map<String, dynamic> place)? onOpenPlace;

  @override
  State<FriendsFeed> createState() => _FriendsFeedState();
}

class _FriendsFeedState extends State<FriendsFeed> {
  static const _likesKey = 'gundua_friend_activity_likes';

  final _favoritesService = FavoritesService();
  final _follows = ExplorerFollows();
  final _matcher = ExplorerMatchingService();
  final _preferences = SharedPreferences.getInstance();
  final _location = LocationPreferenceService.selection;

  List<Map<String, dynamic>> _favorites = [];
  List<Map<String, dynamic>> _visits = [];
  Set<String> _likedIds = {};
  bool _canSaveFavorite = false;
  bool _likesReady = false;
  bool _savingLike = false;
  bool _savingFavorite = false;
  int _historyRequest = 0;
  int _favoriteRevision = 0;

  @override
  void initState() {
    super.initState();
    _location.addListener(_refreshLocation);
    _restoreLocation();
    _loadLikes();
    _follows.load();
    _refreshHistory();
  }

  @override
  void didUpdateWidget(covariant FriendsFeed oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshToken != oldWidget.refreshToken) _refreshHistory();
  }

  @override
  void dispose() {
    _location.removeListener(_refreshLocation);
    _follows.dispose();
    super.dispose();
  }

  void _refreshLocation() => setState(() {});

  Future<void> _restoreLocation() async {
    if (_location.value != null) return;
    try {
      await LocationPreferenceService().getSelected();
    } catch (error) {
      debugPrint('Não foi possível restaurar a localização: $error');
    }
  }

  Future<void> _loadLikes() async {
    try {
      final prefs = await _preferences;
      if (!mounted) return;
      setState(() {
        _likedIds = prefs.getStringList(_likesKey)?.toSet() ?? {};
        _likesReady = true;
      });
    } catch (error) {
      debugPrint('Não foi possível carregar as interações: $error');
    }
  }

  Future<List<Map<String, dynamic>>?> _readPlaces(
    Future<List<Map<String, dynamic>>> Function() read,
  ) async {
    try {
      return await read();
    } catch (error) {
      debugPrint('Não foi possível carregar a atividade de exploração: $error');
      return null;
    }
  }

  Future<void> _refreshHistory() async {
    final request = ++_historyRequest;
    final favoriteRevision = _favoriteRevision;
    final (favorites, visits) = await (
      _readPlaces(_favoritesService.getFavorites),
      _readPlaces(VisitedPlacesService().getVisitedPlaces),
    ).wait;
    if (!mounted || request != _historyRequest) return;
    setState(() {
      if (favorites != null && favoriteRevision == _favoriteRevision) {
        _favorites = favorites;
      }
      _visits = visits ?? _visits;
      _canSaveFavorite = true;
    });
  }

  Future<void> _toggleLike(String id) async {
    if (!_likesReady || _savingLike) return;
    final ids = Set<String>.of(_likedIds);
    if (!ids.add(id)) ids.remove(id);

    setState(() => _savingLike = true);
    try {
      final prefs = await _preferences;
      if (!await prefs.setStringList(_likesKey, ids.toList())) {
        throw StateError('Não foi possível guardar a interação.');
      }
      if (!mounted) return;
      setState(() => _likedIds = ids);
    } catch (_) {
      _showError('Não foi possível guardar a interação.');
    } finally {
      if (mounted) setState(() => _savingLike = false);
    }
  }

  Future<void> _toggleFavorite(Map<String, dynamic> place) async {
    if (_savingFavorite || !_canSaveFavorite) return;
    setState(() => _savingFavorite = true);
    try {
      final saved = await _favoritesService.toggleFavorite(place);
      if (!mounted) return;
      final id = _favoritesService.getPlaceId(place);
      // An earlier refresh may still contain the old favorite state.
      _favoriteRevision++;
      setState(() {
        _favorites = [
          ..._favorites.where(
            (item) => _favoritesService.getPlaceId(item) != id,
          ),
          if (saved) place,
        ];
      });
    } catch (_) {
      _showError('Não foi possível atualizar os favoritos.');
    } finally {
      if (mounted) setState(() => _savingFavorite = false);
    }
  }

  Future<void> _openPlace(Map<String, dynamic> place) async {
    final openPlace = widget.onOpenPlace;
    if (openPlace != null) {
      await openPlace(place);
    } else {
      await Navigator.of(context).push<void>(
        MaterialPageRoute(builder: (_) => PlaceDetailsScreen(place: place)),
      );
    }
    if (mounted) await _refreshHistory();
  }

  Future<void> _openProfile(Explorer explorer) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => UserProfileScreen(
          explorer: explorer,
          follows: _follows,
          onOpenPlace: _openPlace,
          activities: FriendsDemoData.activities
              .where((activity) => activity.explorer.id == explorer.id)
              .toList(),
        ),
      ),
    );
    if (mounted) await _refreshHistory();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Widget _activityCard(CommunityActivity activity) {
    final favoriteId = _favoritesService.getPlaceId(activity.place);
    return _ActivityCard(
      activity: activity,
      liked: _likedIds.contains(activity.id),
      saved: _favorites.any(
        (item) => _favoritesService.getPlaceId(item) == favoriteId,
      ),
      onLike: _likesReady && !_savingLike
          ? () => _toggleLike(activity.id)
          : null,
      onSave: _canSaveFavorite && !_savingFavorite
          ? () => _toggleFavorite(activity.place)
          : null,
      onOpen: () => _openPlace(activity.place),
      onOpenProfile: () => _openProfile(activity.explorer),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final activities = FriendsDemoData.activities;
    final matches = _matcher.rank(
      explorers: FriendsDemoData.explorers,
      visits: _visits,
      favorites: _favorites,
      location: _location.value,
    );
    final hasHistory =
        _visits.isNotEmpty || _favorites.isNotEmpty || _location.value != null;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 720),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: GunduaTheme.pageInset,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Atividade dos amigos', style: text.headlineMedium),
              const SizedBox(height: GunduaTheme.spaceXs),
              Text('Perfis e atividade de demonstração', style: text.bodySmall),
              const SizedBox(height: GunduaTheme.spaceLg),
              _activityCard(activities.first),
              const SizedBox(height: GunduaTheme.sectionGap),
              Text('Exploradores sugeridos', style: text.titleLarge),
              if (!hasHistory) ...[
                const SizedBox(height: GunduaTheme.spaceXs),
                Text(
                  'Guarda lugares ou marca visitas para personalizar a afinidade.',
                  style: text.bodySmall,
                ),
              ],
              const SizedBox(height: GunduaTheme.spaceMd),
              LayoutBuilder(
                builder: (context, constraints) {
                  final width = constraints.maxWidth >= 620
                      ? (constraints.maxWidth -
                                GunduaTheme.spaceMd * (matches.length - 1)) /
                            matches.length
                      : 190.0;
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: GunduaTheme.spaceMd,
                      children: [
                        for (final match in matches)
                          SizedBox(
                            width: width,
                            child: _ExplorerCard(
                              match: match,
                              follows: _follows,
                              onOpenProfile: () => _openProfile(match.explorer),
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: GunduaTheme.sectionGap),
              for (final activity in activities.skip(1)) ...[
                _activityCard(activity),
                const SizedBox(height: GunduaTheme.spaceMd),
              ],
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (_) => _PhotoCredits(activities: activities),
                  ),
                  child: const Text('Créditos das fotografias'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({
    required this.activity,
    required this.liked,
    required this.saved,
    required this.onLike,
    required this.onSave,
    required this.onOpen,
    required this.onOpenProfile,
  });

  final CommunityActivity activity;
  final bool liked;
  final bool saved;
  final VoidCallback? onLike;
  final VoidCallback? onSave;
  final VoidCallback onOpen;
  final VoidCallback onOpenProfile;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final place = Place.fromMap(activity.place);
    const photoInset = GunduaTheme.spaceMd;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: onOpenProfile,
            child: Padding(
              padding: const EdgeInsets.all(GunduaTheme.spaceMd),
              child: Row(
                children: [
                  ExplorerAvatar(explorer: activity.explorer, size: 44),
                  const SizedBox(width: GunduaTheme.spaceMd),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(activity.explorer.name, style: text.titleMedium),
                        Text(
                          '${activity.kind.label} · ${activity.time}',
                          style: text.bodySmall?.merge(
                            GunduaTheme.tabularNumbers,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: GunduaTheme.spaceSm),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: GunduaTheme.accent,
                  ),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: onOpen,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (activity.photo case final photo?)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: photoInset),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                        GunduaTheme.nestedRadius(
                          GunduaTheme.cardRadius,
                          photoInset,
                        ),
                      ),
                      child: AspectRatio(
                        aspectRatio: 1.9,
                        child: Image.asset(
                          photo.asset,
                          fit: BoxFit.cover,
                          excludeFromSemantics: true,
                          errorBuilder: (_, _, _) =>
                              const ColoredBox(color: GunduaTheme.image),
                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.all(GunduaTheme.spaceMd),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(place.name, style: text.titleLarge),
                            const SizedBox(height: GunduaTheme.spaceXs),
                            Text(
                              place.locality ?? place.address,
                              style: text.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: GunduaTheme.spaceSm),
                      const Icon(
                        Icons.chevron_right_rounded,
                        color: GunduaTheme.accent,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: GunduaTheme.spaceSm,
            ),
            child: Wrap(
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Semantics(
                  toggled: liked,
                  child: Tooltip(
                    message: liked ? 'Retirar gosto' : 'Gostar da atividade',
                    child: TextButton.icon(
                      onPressed: onLike,
                      icon: Icon(
                        liked
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        size: 20,
                      ),
                      label: Text(
                        '${activity.likes + (liked ? 1 : 0)}',
                        style: GunduaTheme.tabularNumbers,
                      ),
                      style: TextButton.styleFrom(
                        foregroundColor: GunduaTheme.terracotta,
                      ),
                    ),
                  ),
                ),
                Semantics(
                  toggled: saved,
                  child: TextButton.icon(
                    onPressed: onSave,
                    icon: Icon(
                      saved
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      size: 20,
                    ),
                    label: Text(saved ? 'Guardado' : 'Guardar'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ExplorerCard extends StatelessWidget {
  const _ExplorerCard({
    required this.match,
    required this.follows,
    required this.onOpenProfile,
  });

  final ExplorerMatch match;
  final ExplorerFollows follows;
  final VoidCallback onOpenProfile;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final explorer = match.explorer;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: onOpenProfile,
            child: Padding(
              padding: const EdgeInsets.all(GunduaTheme.spaceMd),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ExplorerAvatar(explorer: explorer, size: 52),
                      const Icon(
                        Icons.chevron_right_rounded,
                        color: GunduaTheme.accent,
                      ),
                    ],
                  ),
                  const SizedBox(height: GunduaTheme.spaceSm),
                  Text(explorer.name, style: text.titleMedium),
                  Text(explorer.area, style: text.bodySmall),
                  const SizedBox(height: GunduaTheme.spaceSm),
                  Text(
                    '${match.percent}% de afinidade',
                    style: text.bodySmall
                        ?.copyWith(
                          color: GunduaTheme.forest,
                          fontWeight: FontWeight.w700,
                        )
                        .merge(GunduaTheme.tabularNumbers),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              GunduaTheme.spaceMd,
              0,
              GunduaTheme.spaceMd,
              GunduaTheme.spaceMd,
            ),
            child: FollowExplorerButton(
              explorerId: explorer.id,
              follows: follows,
            ),
          ),
        ],
      ),
    );
  }
}

class _PhotoCredits extends StatelessWidget {
  const _PhotoCredits({required this.activities});

  final Iterable<CommunityActivity> activities;

  Future<void> _openLink(BuildContext context, Uri uri) async {
    if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir a ligação.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      scrollable: true,
      title: const Text('Créditos das fotografias'),
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Imagens do Wikimedia Commons redimensionadas e convertidas para WebP.',
          ),
          const SizedBox(height: 8),
          for (final activity in activities)
            if (activity.photo case final photo?) ...[
              TextButton(
                onPressed: () => _openLink(
                  context,
                  Uri.https(
                    'commons.wikimedia.org',
                    '/wiki/File:${photo.commonsFile}',
                  ),
                ),
                child: Text(activity.place['name'].toString()),
              ),
              Text('${photo.author} · ${photo.license}'),
            ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => _openLink(
            context,
            Uri.https('creativecommons.org', '/licenses/by-sa/4.0/'),
          ),
          child: const Text('Licença CC BY-SA 4.0'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Fechar'),
        ),
      ],
    );
  }
}
