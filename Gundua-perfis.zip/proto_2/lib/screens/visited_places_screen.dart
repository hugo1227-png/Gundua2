import 'package:flutter/material.dart';

import '../services/visited_places_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/place_photo.dart';
import 'place_details_screen.dart';

class VisitedPlacesScreen extends StatefulWidget {
  const VisitedPlacesScreen({super.key});

  @override
  State<VisitedPlacesScreen> createState() => _VisitedPlacesScreenState();
}

class _VisitedPlacesScreenState extends State<VisitedPlacesScreen> {
  static const Color background = GunduaTheme.canvas;
  static const Color textColor = GunduaTheme.ink;
  static const Color secondaryColor = GunduaTheme.muted;
  static const Color accentColor = GunduaTheme.accent;

  final VisitedPlacesService _visitedPlacesService = VisitedPlacesService();

  List<Map<String, dynamic>> _places = [];
  bool _isLoading = true;
  String? _removingPlaceId;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadPlaces();
  }

  Future<void> _loadPlaces() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final places = await _visitedPlacesService.getVisitedPlaces();
      if (!mounted) return;

      setState(() {
        _places = places.reversed.toList();
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _errorMessage = 'Não foi possível carregar os lugares visitados.';
      });
      debugPrint('Erro ao carregar lugares visitados: $error');
    }
  }

  String _placeName(Map<String, dynamic> place) {
    final name = place['name']?.toString().trim() ?? '';
    if (name.isNotEmpty) return name;

    final displayName = place['display_name']?.toString().trim() ?? '';
    if (displayName.isNotEmpty) {
      return displayName.split(',').first.trim();
    }

    return 'Lugar sem nome';
  }

  String _placeLocation(Map<String, dynamic> place) {
    final location = place['location']?.toString().trim() ?? '';
    if (location.isNotEmpty) return location;

    final displayName = place['display_name']?.toString().trim() ?? '';
    if (displayName.isNotEmpty) return displayName;

    final latitude = (place['latitude'] ?? place['lat'])?.toString() ?? '';
    final longitude = (place['longitude'] ?? place['lon'])?.toString() ?? '';

    if (latitude.isNotEmpty && longitude.isNotEmpty) {
      return 'Coordenadas: $latitude, $longitude';
    }

    return 'Localização não disponível';
  }

  Map<String, dynamic> _preparePlace(Map<String, dynamic> place) {
    final address = place['address'];
    String country = place['country']?.toString() ?? '';

    if (country.isEmpty && address is Map) {
      country = address['country']?.toString() ?? '';
    }

    return {
      ...place,
      'name': _placeName(place),
      'location': _placeLocation(place),
      'country': country,
      'image': place['image'] ?? place['image_url'],
      'latitude': place['latitude'] ?? place['lat'],
      'longitude': place['longitude'] ?? place['lon'],
    };
  }

  Future<void> _openPlace(Map<String, dynamic> place) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlaceDetailsScreen(place: _preparePlace(place)),
      ),
    );

    if (mounted) await _loadPlaces();
  }

  Future<void> _removePlace(Map<String, dynamic> place) async {
    if (_removingPlaceId != null) return;

    final id = _visitedPlacesService.getPlaceId(place);
    setState(() => _removingPlaceId = id);

    try {
      await _visitedPlacesService.removeVisitedPlace(place);
      if (!mounted) return;

      setState(() {
        _places.removeWhere(
          (item) => _visitedPlacesService.getPlaceId(item) == id,
        );
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lugar removido dos visitados.')),
      );
    } catch (error) {
      if (!mounted) return;

      debugPrint('Erro ao remover lugar visitado: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível remover o lugar.')),
      );
    } finally {
      if (mounted) setState(() => _removingPlaceId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        backgroundColor: background,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: const Text(
          'Lugares visitados',
          style: TextStyle(color: textColor, fontWeight: FontWeight.w700),
        ),
        iconTheme: const IconThemeData(color: textColor),
        actions: [
          IconButton(
            onPressed: _isLoading ? null : _loadPlaces,
            tooltip: 'Atualizar',
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          semanticsLabel: 'A carregar lugares visitados',
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.cloud_off_outlined,
                size: 48,
                color: secondaryColor,
              ),
              const SizedBox(height: 14),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: secondaryColor),
              ),
              const SizedBox(height: 14),
              OutlinedButton(
                onPressed: _loadPlaces,
                child: const Text('Tentar novamente'),
              ),
            ],
          ),
        ),
      );
    }

    if (_places.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(
                Icons.travel_explore_outlined,
                size: 62,
                color: secondaryColor,
              ),
              SizedBox(height: 16),
              Text(
                'Ainda não visitaste nenhum lugar',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: textColor,
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Quando marcares um lugar como visitado, ele aparecerá aqui.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: secondaryColor,
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      color: accentColor,
      onRefresh: _loadPlaces,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(
          GunduaTheme.pageInset,
          GunduaTheme.spaceLg,
          GunduaTheme.pageInset,
          GunduaTheme.sectionGap,
        ),
        itemCount: _places.length,
        itemBuilder: (context, index) => _buildPlaceCard(_places[index]),
      ),
    );
  }

  Widget _buildPlaceCard(Map<String, dynamic> place) {
    final name = _placeName(place);
    final location = _placeLocation(place);
    final image = (place['image'] ?? place['image_url'])?.toString();
    final removing =
        _removingPlaceId == _visitedPlacesService.getPlaceId(place);

    return Card(
      margin: const EdgeInsets.only(bottom: GunduaTheme.spaceMd),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          InkWell(
            onTap: () => _openPlace(place),
            child: Row(
              children: [
                if (image?.isNotEmpty == true)
                  SizedBox.square(dimension: 92, child: PlacePhoto(url: image)),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(GunduaTheme.spaceLg),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: GunduaTheme.spaceXs),
                        Text(
                          location,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.merge(GunduaTheme.tabularNumbers),
                        ),
                      ],
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 12),
                  child: Icon(Icons.chevron_right, color: secondaryColor),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: _removingPlaceId != null
                  ? null
                  : () => _removePlace(place),
              icon: removing
                  ? const SizedBox.square(
                      dimension: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.delete_outline_rounded, size: 19),
              label: Text(removing ? 'A remover…' : 'Remover do histórico'),
            ),
          ),
        ],
      ),
    );
  }
}
