import 'dart:async';

import 'package:flutter/material.dart';

import '../services/profile_service.dart';
import '../theme/gundua_theme.dart';
import '../widgets/gundua_brand.dart';
import 'main_navigation_screen.dart';
import 'welcome_get_started_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const _splashDuration = Duration(seconds: 2);

  late final AnimationController _controller;
  late final Animation<double> _opacity;
  late final Animation<double> _scale;
  late final Timer _transitionTimer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 720),
    );
    _opacity = _controller.drive(CurveTween(curve: Curves.easeOut));
    _scale = _controller
        .drive(CurveTween(curve: Curves.easeOutCubic))
        .drive(Tween(begin: .88, end: 1.0));
    _controller.forward();

    final destination = _readDestination();
    _transitionTimer = Timer(_splashDuration, () => _open(destination));
  }

  Future<Widget> _readDestination() async {
    try {
      final signedIn = await ProfileService().isLoggedIn();
      if (signedIn) return const MainNavigationScreen();
    } catch (error) {
      debugPrint('Não foi possível restaurar a sessão: $error');
    }
    return const WelcomeGetStartedScreen();
  }

  Future<void> _open(Future<Widget> destination) async {
    final screen = await destination;
    if (!mounted) return;

    final duration = MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : const Duration(milliseconds: 230);
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        pageBuilder: (_, _, _) => screen,
        transitionDuration: duration,
        reverseTransitionDuration: duration,
        transitionsBuilder: (_, animation, _, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _transitionTimer.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final branding = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const GunduaBrandMark(size: 104),
        const SizedBox(height: 22),
        const GunduaWordmark(size: 47),
        const SizedBox(height: 10),
        Text(
          'A tua cidade por descobrir.',
          textAlign: TextAlign.center,
          style: Theme.of(
            context,
          ).textTheme.bodyLarge?.copyWith(color: GunduaTheme.muted),
        ),
      ],
    );

    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -.16),
            radius: .93,
            colors: [GunduaTheme.moss, GunduaTheme.canvas, GunduaTheme.cream],
            stops: [0, .64, 1],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: MediaQuery.disableAnimationsOf(context)
                  ? branding
                  : FadeTransition(
                      opacity: _opacity,
                      child: ScaleTransition(scale: _scale, child: branding),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
