import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'gundua_api_client.dart';

/// Histórico de visualizações do próprio dispositivo. Não representa
/// estatísticas globais de visitantes nem lugares físicos frequentados.
class WeeklyHighlightsService {
  static const _key = 'gundua_weekly_place_views';

  Future<void> recordView(Map<String, dynamic> place, {DateTime? at}) async {
    if (place['isCommunityPlace'] != true &&
        GunduaApiClient.isConfigured &&
        await GunduaApiClient().hasSession) {
      await GunduaApiClient().post('/me/views', {'place': place});
    }
    final prefs = await SharedPreferences.getInstance();
    final now = at ?? DateTime.now();
    // A view recorded late must leave newer views in the history.
    final recent = _events(prefs, now, includeFuture: true);
    recent.add({'time': now.toIso8601String(), 'place': place});
    final retained = recent.length > 500
        ? recent.sublist(recent.length - 500)
        : recent;
    await prefs.setString(_key, jsonEncode(retained));
  }

  /// A API conta marcações explícitas de visitas de todos os participantes.
  /// Não mede presença GPS nem número físico de visitantes.
  Future<Map<String, dynamic>?> communityMostVisited() async {
    if (!GunduaApiClient.isConfigured) return null;
    final data =
        await GunduaApiClient().get('/analytics/weekly?metric=visits') as Map;
    final result = data['result'];
    if (result is! Map) return null;
    final place = result['place'];
    if (place is! Map) return null;
    return {
      ...Map<String, dynamic>.from(place),
      'weeklyCommunityVisitCount': result['count'],
    };
  }

  Future<Map<String, dynamic>?> mostViewedByMe({DateTime? at}) async {
    final prefs = await SharedPreferences.getInstance();
    final events = _events(prefs, at ?? DateTime.now());
    final counts = <String, int>{};
    final places = <String, Map<String, dynamic>>{};
    for (final event in events) {
      final place = event['place'];
      if (place is! Map) continue;
      final data = Map<String, dynamic>.from(place);
      final id =
          (data['placeId'] ??
                  data['place_id'] ??
                  '${data['name']}_${data['latitude']}_${data['longitude']}')
              .toString();
      counts[id] = (counts[id] ?? 0) + 1;
      places[id] = data;
    }
    if (counts.isEmpty) return null;
    final best = counts.keys.reduce((a, b) => counts[a]! >= counts[b]! ? a : b);
    return {...places[best]!, 'weeklyViewCountOnDevice': counts[best]};
  }

  List<Map<String, dynamic>> _events(
    SharedPreferences prefs,
    DateTime now, {
    bool includeFuture = false,
  }) {
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final since = now.subtract(const Duration(days: 7));
      return decoded
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .where((event) {
            final date = DateTime.tryParse((event['time'] ?? '').toString());
            return date != null &&
                !date.isBefore(since) &&
                (includeFuture || !date.isAfter(now));
          })
          .toList();
    } catch (_) {
      return [];
    }
  }
}
