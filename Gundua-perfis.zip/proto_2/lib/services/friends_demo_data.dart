import '../models/community_activity.dart';
import 'curated_places_service.dart';

abstract final class FriendsDemoData {
  static final _places = {
    for (final place in CuratedPlacesService.lisbonHiddenGems)
      place['placeId']: place,
  };

  static Map<String, dynamic> _place(String id) =>
      _places['lisbon-hidden-$id']!;

  static String _photo(String id) =>
      CuratedPlacesService.photoAssets['lisbon-hidden-$id']!;

  static final _ines = Explorer(
    id: 'demo-ines',
    name: 'Inês Matos',
    area: 'Arroios, Lisboa',
    avatarAsset: 'assets/images/explorer_ines.webp',
    followerCount: 127,
    followingCount: 86,
    latitude: 38.7290,
    longitude: -9.1333,
    visits: [_place('estufa-fria'), _place('torel'), _place('marioneta')],
    favorites: [_place('estufa-fria'), _place('torel')],
    reviews: [
      ExplorerReview(
        place: _place('estufa-fria'),
        rating: 5,
        comment: 'É o meu refúgio nas tardes quentes. O caminho junto aos lagos é especialmente bonito.',
      ),
      ExplorerReview(
        place: _place('torel'),
        rating: 4,
        comment: 'Vale a subida pela vista e pela sombra. Levei um livro e fiquei até ao pôr do sol.',
      ),
    ],
  );

  static final _tiago = Explorer(
    id: 'demo-tiago',
    name: 'Tiago Costa',
    area: 'Graça, Lisboa',
    avatarAsset: 'assets/images/explorer_tiago.webp',
    followerCount: 94,
    followingCount: 71,
    latitude: 38.7169,
    longitude: -9.1329,
    visits: [_place('feira-ladra'), _place('monte-agudo'), _place('mae-dagua')],
    favorites: [_place('feira-ladra'), _place('monte-agudo')],
    reviews: [
      ExplorerReview(
        place: _place('feira-ladra'),
        rating: 5,
        comment: 'Cheguei cedo e encontrei postais antigos de Lisboa. Dá gosto conversar com quem está nas bancas.',
      ),
    ],
  );

  static final _marta = Explorer(
    id: 'demo-marta',
    name: 'Marta Lopes',
    area: 'Santos, Lisboa',
    avatarAsset: 'assets/images/explorer_marta.webp',
    followerCount: 166,
    followingCount: 104,
    latitude: 38.7065,
    longitude: -9.1559,
    visits: [_place('marioneta'), _place('bordalo'), _place('casa-alentejo')],
    favorites: [_place('marioneta'), _place('casa-alentejo')],
    reviews: [
      ExplorerReview(
        place: _place('marioneta'),
        rating: 5,
        comment: 'Fiquei surpreendida com as peças de teatro de sombras. Há pormenores para descobrir em cada sala.',
      ),
      ExplorerReview(
        place: _place('casa-alentejo'),
        rating: 4,
        comment: 'O pátio interior é um sossego no meio da Baixa. Passei lá antes de um concerto.',
      ),
    ],
  );

  static final explorers = List<Explorer>.unmodifiable([_ines, _tiago, _marta]);

  static final activities = List<CommunityActivity>.unmodifiable([
    CommunityActivity(
      id: 'demo-estufa-fria',
      explorer: _ines,
      kind: ActivityKind.saved,
      place: _place('estufa-fria'),
      time: 'Há 2\u00A0h',
      likes: 12,
      photo: (
        asset: _photo('estufa-fria'),
        author: '0000ff',
        license: 'CC BY-SA 4.0',
        commonsFile: 'Estufa-Fria-Lisboa-2017.jpg',
      ),
    ),
    CommunityActivity(
      id: 'demo-feira-ladra',
      explorer: _tiago,
      kind: ActivityKind.added,
      place: _place('feira-ladra'),
      time: 'Ontem',
      likes: 8,
      photo: (
        asset: _photo('feira-ladra'),
        author: 'Carlos Luis M C da Cruz',
        license: 'Domínio público',
        commonsFile: 'Feira_da_ladra.jpg',
      ),
    ),
    CommunityActivity(
      id: 'demo-marioneta',
      explorer: _marta,
      kind: ActivityKind.checkIn,
      place: _place('marioneta'),
      time: 'Ontem',
      likes: 16,
      photo: (
        asset: _photo('marioneta'),
        author: 'GualdimG',
        license: 'CC BY-SA 4.0',
        commonsFile: 'Museu_da_Marioneta_(Lisboa)_01.jpg',
      ),
    ),
  ]);
}
