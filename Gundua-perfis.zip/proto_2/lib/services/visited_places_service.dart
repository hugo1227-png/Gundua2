import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'gundua_api_client.dart';

class VisitedPlacesService {
  // Mantém a chave utilizada anteriormente pelo GUNDUA.
  static const String _storageKey = 'gundua_visited_places';

  String getPlaceId(Map<String, dynamic> place) {
    final osmType = (place['osm_type'] ?? place['osmType'])?.toString() ?? '';
    final osmId = (place['osm_id'] ?? place['osmId'])?.toString() ?? '';

    if (osmType.isNotEmpty && osmId.isNotEmpty) {
      return '$osmType-$osmId';
    }

    final placeId = (place['place_id'] ?? place['placeId'])?.toString() ?? '';

    if (placeId.isNotEmpty) {
      return 'place-$placeId';
    }

    final latitude = (place['lat'] ?? place['latitude'])?.toString() ?? '';
    final longitude = (place['lon'] ?? place['longitude'])?.toString() ?? '';
    final name = (place['name'] ?? place['display_name'] ?? '')
        .toString()
        .trim()
        .toLowerCase();

    // Compatível com o formato anteriormente utilizado pelo GUNDUA.
    return '$latitude-$longitude-$name';
  }

  Future<List<Map<String, dynamic>>> getVisitedPlaces() async {
    final local = await _getLocalVisits();
    if (!GunduaApiClient.isConfigured) return local;

    final community = local.where((place) => place['isCommunityPlace'] == true);
    try {
      final data = await GunduaApiClient().get('/me/visits') as Map;
      return [
        for (final raw in (data['items'] as List).whereType<Map>())
          Map<String, dynamic>.from(raw),
        ...community,
      ];
    } catch (_) {
      if (community.isEmpty) rethrow;
      return community.toList();
    }
  }

  Future<List<Map<String, dynamic>>> _getLocalVisits() async =>
      _readLocalVisits(await SharedPreferences.getInstance());

  List<Map<String, dynamic>> _readLocalVisits(SharedPreferences prefs) {
    final savedData = prefs.getString(_storageKey);

    if (savedData == null || savedData.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(savedData);
      if (decoded is! List) return [];

      return decoded
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<bool> isVisited(Map<String, dynamic> place) async {
    final places = place['isCommunityPlace'] == true
        ? await _getLocalVisits()
        : await getVisitedPlaces();
    final id = getPlaceId(place);

    return places.any((item) => getPlaceId(item) == id);
  }

  bool _usesServer(Map<String, dynamic> place) =>
      GunduaApiClient.isConfigured && place['isCommunityPlace'] != true;

  Future<void> markAsVisited(Map<String, dynamic> place) async {
    if (_usesServer(place)) {
      await GunduaApiClient().post('/me/visits', {'place': place});
    } else {
      await _changeLocalVisit(place, visited: true);
    }
  }

  Future<void> removeVisitedPlace(Map<String, dynamic> place) async {
    if (_usesServer(place)) {
      final id = Uri.encodeComponent(getPlaceId(place));
      await GunduaApiClient().delete('/me/visits/$id');
    } else {
      await _changeLocalVisit(place, visited: false);
    }
  }

  // true quando fica marcado como visitado; false quando é removido.
  Future<bool> toggleVisited(Map<String, dynamic> place) async {
    if (!_usesServer(place)) return _changeLocalVisit(place);

    if (await isVisited(place)) {
      await removeVisitedPlace(place);
      return false;
    }
    await markAsVisited(place);
    return true;
  }

  Future<bool> _changeLocalVisit(
    Map<String, dynamic> place, {
    bool? visited,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final places = _readLocalVisits(prefs);
    final id = getPlaceId(place);
    final alreadyVisited = places.any((item) => getPlaceId(item) == id);
    final shouldVisit = visited ?? !alreadyVisited;
    if (shouldVisit == alreadyVisited) return shouldVisit;

    if (shouldVisit) {
      places.add(Map<String, dynamic>.from(place));
    } else {
      places.removeWhere((item) => getPlaceId(item) == id);
    }

    if (!await prefs.setString(_storageKey, jsonEncode(places))) {
      throw StateError(
        shouldVisit
            ? 'Não foi possível guardar a visita.'
            : 'Não foi possível remover a visita.',
      );
    }
    return shouldVisit;
  }
}
