import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'gundua_api_client.dart';

class FavoritesService {
  static const String _storageKey = 'gundua_favorite_places';

  // Identificador consistente para reconhecer o mesmo lugar em vários ecrãs.
  String getPlaceId(Map<String, dynamic> place) {
    final osmType = place['osm_type'] ?? place['osmType'];
    final osmId = place['osm_id'] ?? place['osmId'];

    if (osmType != null && osmId != null) {
      return '$osmType-$osmId';
    }

    final placeId = place['place_id'] ?? place['placeId'];
    if (placeId != null) {
      return 'place-$placeId';
    }

    final latitude = place['lat'] ?? place['latitude'] ?? '';
    final longitude = place['lon'] ?? place['longitude'] ?? '';
    final name = place['name'] ?? place['display_name'] ?? '';

    return '$latitude-$longitude-$name'.toString().trim().toLowerCase();
  }

  Future<List<Map<String, dynamic>>> getFavorites() async {
    final local = await _getLocalFavorites();
    if (!GunduaApiClient.isConfigured) return local;

    final community = local.where((place) => place['isCommunityPlace'] == true);
    try {
      final data = await GunduaApiClient().get('/me/favorites') as Map;
      return [
        ...community,
        for (final raw in (data['items'] as List).whereType<Map>())
          Map<String, dynamic>.from(raw),
      ];
    } catch (_) {
      if (community.isEmpty) rethrow;
      return community.toList();
    }
  }

  Future<List<Map<String, dynamic>>> _getLocalFavorites() async =>
      _readLocalFavorites(await SharedPreferences.getInstance());

  List<Map<String, dynamic>> _readLocalFavorites(SharedPreferences prefs) {
    final data = prefs.getString(_storageKey);

    if (data == null || data.isEmpty) return [];

    try {
      final decoded = jsonDecode(data);
      if (decoded is! List) return [];

      return decoded
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<bool> isFavorite(Map<String, dynamic> place) async {
    final favorites = place['isCommunityPlace'] == true
        ? await _getLocalFavorites()
        : await getFavorites();
    final placeId = getPlaceId(place);

    return favorites.any((favorite) => getPlaceId(favorite) == placeId);
  }

  bool _usesServer(Map<String, dynamic> place) =>
      GunduaApiClient.isConfigured && place['isCommunityPlace'] != true;

  Future<bool> addFavorite(Map<String, dynamic> place) async {
    if (!_usesServer(place)) return _changeLocalFavorite(place, saved: true);
    await GunduaApiClient().post('/me/favorites', {'place': place});
    return true;
  }

  Future<bool> removeFavorite(Map<String, dynamic> place) async {
    if (!_usesServer(place)) return _changeLocalFavorite(place, saved: false);
    final id = Uri.encodeComponent(getPlaceId(place));
    await GunduaApiClient().delete('/me/favorites/$id');
    return false;
  }

  // Devolve true quando o lugar fica guardado e false quando é removido.
  Future<bool> toggleFavorite(Map<String, dynamic> place) async {
    if (!_usesServer(place)) return _changeLocalFavorite(place);
    return await isFavorite(place) ? removeFavorite(place) : addFavorite(place);
  }

  Future<bool> _changeLocalFavorite(
    Map<String, dynamic> place, {
    bool? saved,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = _readLocalFavorites(prefs);
    final placeId = getPlaceId(place);
    final alreadySaved = favorites.any((item) => getPlaceId(item) == placeId);
    final shouldSave = saved ?? !alreadySaved;
    if (shouldSave == alreadySaved) return shouldSave;

    if (shouldSave) {
      favorites.add(Map<String, dynamic>.from(place));
    } else {
      favorites.removeWhere((item) => getPlaceId(item) == placeId);
    }

    if (!await prefs.setString(_storageKey, jsonEncode(favorites))) {
      throw StateError(
        shouldSave
            ? 'Não foi possível guardar o lugar.'
            : 'Não foi possível remover o lugar.',
      );
    }
    return shouldSave;
  }
}
