import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/place.dart';

/// Locally contributed places and their photos, shared by Home and Explore.
class CommunityPlacesService extends ChangeNotifier {
  CommunityPlacesService();

  static final instance = CommunityPlacesService();
  static const _storageKey = 'gundua_community_places';
  static const _idPrefix = 'community-';
  static const _photoPrefix = 'gundua-photo:';
  static const maxPhotoBytes = 1024 * 1024;

  List<Place> _places = const [];
  Map<String, Uint8List> _photos = {};
  Future<void>? _loading;
  Future<void> _pendingWrite = Future.value();

  List<Place> get places => _places;

  static bool isLocalPlaceId(String id) => id.startsWith(_idPrefix);

  static bool isLocalPhoto(String reference) =>
      reference.startsWith(_photoPrefix);

  Uint8List? photo(String reference) => _photos[reference];

  Future<void> load() => _loading ??= _restore();

  Future<void> _restore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null) return;
      final entries = jsonDecode(raw);
      if (entries is! List) return;

      final places = <Place>[];
      final photos = <String, Uint8List>{};
      for (final entry in entries.whereType<Map<String, dynamic>>()) {
        final data = entry['place'];
        if (data is! Map<String, dynamic>) continue;
        final place = Place.fromMap(data);
        places.add(place);
        final reference = place.imageUrl;
        final encoded = entry['photo'];
        if (reference != null && encoded is String) {
          try {
            photos[reference] = base64Decode(encoded);
          } on FormatException {
            // Keep the place available if its photo is unreadable.
          }
        }
      }
      _places = List.unmodifiable(places);
      _photos = photos;
      notifyListeners();
    } catch (error) {
      _loading = null;
      debugPrint('Não foi possível carregar os lugares adicionados: $error');
    }
  }

  Future<Place> add({
    required String name,
    required String category,
    required List<String> categories,
    required String address,
    required String description,
    Uint8List? photo,
  }) async {
    if (photo != null && photo.lengthInBytes > maxPhotoBytes) {
      throw ArgumentError('A fotografia deve ter, no máximo, 1 MB.');
    }
    await load();

    // Serialize simultaneous writes so a later save includes earlier places.
    final pending = _pendingWrite.then((_) async {
      final timestamp = DateTime.now().microsecondsSinceEpoch;
      final id = '$_idPrefix$timestamp-${_places.length}';
      final image = photo == null ? null : '$_photoPrefix$id';
      final place = Place(
        id: id,
        name: name.trim(),
        address: address.trim(),
        category: category,
        categories: List.unmodifiable(categories),
        description: description.trim(),
        latitude: 0,
        longitude: 0,
        imageUrl: image,
        isCommunityPlace: true,
      );
      final places = [place, ..._places];
      final photos = Map<String, Uint8List>.of(_photos);
      if (image != null && photo != null) photos[image] = photo;

      final prefs = await SharedPreferences.getInstance();
      final saved = await prefs.setString(
        _storageKey,
        jsonEncode([
          for (final item in places)
            {
              'place': item.toMap(),
              if (photos[item.imageUrl] case final bytes?)
                'photo': base64Encode(bytes),
            },
        ]),
      );
      if (!saved) throw StateError('Não foi possível guardar o lugar.');

      _places = List.unmodifiable(places);
      _photos = photos;
      notifyListeners();
      return place;
    });
    _pendingWrite = pending.then<void>(
      (_) {},
      onError: (Object _, StackTrace _) {},
    );
    return pending;
  }
}
