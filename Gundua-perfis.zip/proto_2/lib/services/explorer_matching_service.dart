import 'dart:math';

import 'package:geolocator/geolocator.dart';

import '../models/community_activity.dart';
import 'favorites_service.dart';
import 'location_service.dart';
import 'place_search_service.dart';

typedef ExplorerMatch = ({Explorer explorer, int percent});

class ExplorerMatchingService {
  static const _sampleCount = 512;
  static const _neutral = 0.5;

  List<ExplorerMatch> rank({
    required Iterable<Explorer> explorers,
    required Iterable<Map<String, dynamic>> visits,
    required Iterable<Map<String, dynamic>> favorites,
    AppLocation? location,
  }) {
    final visitedCategories = _visitedCategories(visits);
    final favoriteIds = favorites.map(FavoritesService().getPlaceId).toSet();
    final matches = <ExplorerMatch>[];

    for (final explorer in explorers) {
      final categories = _similarity(
        visitedCategories,
        _visitedCategories(explorer.visits),
      );
      final sharedSpots = _similarity(
        favoriteIds,
        explorer.favorites.map(FavoritesService().getPlaceId).toSet(),
      );
      final proximity = location == null
          ? _neutral
          : exp(
              -Geolocator.distanceBetween(
                    location.latitude,
                    location.longitude,
                    explorer.latitude,
                    explorer.longitude,
                  ) /
                  30000,
            );

      final percent =
          visitedCategories.isEmpty && favoriteIds.isEmpty && location == null
          ? 50
          : _sampleMatch(categories, sharedSpots, proximity);
      matches.add((explorer: explorer, percent: percent));
    }

    return matches..sort((a, b) {
      final byScore = b.percent.compareTo(a.percent);
      return byScore == 0
          ? a.explorer.name.compareTo(b.explorer.name)
          : byScore;
    });
  }

  int _sampleMatch(double categories, double favorites, double proximity) {
    // Each trial picks a signal by weight, then samples a match from it.
    // The same seeded trials keep comparisons stable as the UI rebuilds.
    final random = Random(21);
    var hits = 0;
    for (var i = 0; i < _sampleCount; i++) {
      final chance = switch (random.nextInt(100)) {
        < 45 => categories,
        < 80 => favorites,
        _ => proximity,
      };
      if (random.nextDouble() < chance) hits++;
    }
    return (100 * hits / _sampleCount).round();
  }

  double _similarity(Set<String> mine, Set<String> other) {
    if (mine.isEmpty || other.isEmpty) return _neutral;
    return mine.intersection(other).length / mine.union(other).length;
  }

  Set<String> _visitedCategories(Iterable<Map<String, dynamic>> visits) => {
    for (final place in visits) ..._categoriesFor(place),
  };

  Set<String> _categoriesFor(Map<String, dynamic> place) {
    final matches = PlaceSearchService.categoryFilters.keys
        .where(
          (category) => PlaceSearchService.matchesCategory(place, category),
        )
        .toSet();
    if (matches.isNotEmpty) return matches;

    final raw = (place['categoryLabel'] ?? place['category'] ?? '').toString();
    final label = raw.trim().toLowerCase().replaceAll('_', ' ');
    if (label.isEmpty ||
        label == 'ponto de interesse' ||
        label == 'point of interest') {
      return {};
    }

    final category =
        PlaceSearchService.categoryFromTerm(label) ??
        switch (label) {
          'restaurant' || 'cafe' || 'café' => 'Restaurantes',
          'museum' => 'Museus',
          'park' || 'garden' || 'jardim' || 'jardim histórico' => 'Natureza',
          'património' || 'monument' || 'historical landmark' => 'Monumentos',
          'theatre' || 'theater' || 'cultural center' => 'Cultura',
          'beach' => 'Praias',
          'square' => 'Praças',
          _ => label,
        };
    return {category};
  }
}
