import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ExplorerFollows extends ChangeNotifier {
  static const _storageKey = 'gundua_followed_explorers';

  Set<String> _following = {};
  bool _loading = true;
  bool _disposed = false;
  String? _savingId;

  bool get isBusy => _loading || _savingId != null;
  bool isUpdating(String id) => _loading || _savingId == id;
  bool follows(String id) => _following.contains(id);

  Future<void> load() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      _following = _read(preferences);
    } catch (error) {
      debugPrint('Não foi possível carregar os exploradores seguidos: $error');
    } finally {
      _loading = false;
      _notify();
    }
  }

  Future<void> toggle(String id) async {
    if (isBusy) return;
    _savingId = id;
    _notify();

    try {
      final preferences = await SharedPreferences.getInstance();
      final next = Set<String>.of(_following);
      if (!next.add(id)) next.remove(id);
      if (!await preferences.setStringList(_storageKey, next.toList())) {
        throw StateError('Não foi possível atualizar o seguimento.');
      }
      _following = next;
    } finally {
      _savingId = null;
      _notify();
    }
  }

  Set<String> _read(SharedPreferences preferences) =>
      preferences.getStringList(_storageKey)?.toSet() ?? {};

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
