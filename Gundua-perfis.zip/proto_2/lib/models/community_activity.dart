class Explorer {
  const Explorer({
    required this.id,
    required this.name,
    required this.area,
    required this.latitude,
    required this.longitude,
    required this.visits,
    required this.favorites,
    this.avatarAsset,
    this.followerCount = 0,
    this.followingCount = 0,
    this.reviews = const [],
  });

  final String id;
  final String name;
  final String area;
  final double latitude;
  final double longitude;
  final List<Map<String, dynamic>> visits;
  final List<Map<String, dynamic>> favorites;
  final String? avatarAsset;
  final int followerCount;
  final int followingCount;
  final List<ExplorerReview> reviews;
}

class ExplorerReview {
  const ExplorerReview({
    required this.place,
    required this.rating,
    required this.comment,
  });

  final Map<String, dynamic> place;
  final int rating;
  final String comment;
}

enum ActivityKind {
  saved('Guardou um local'),
  added('Adicionou um local'),
  checkIn('Fez check-in');

  const ActivityKind(this.label);

  final String label;
}

typedef ActivityPhoto = ({
  String asset,
  String author,
  String license,
  String commonsFile,
});

class CommunityActivity {
  const CommunityActivity({
    required this.id,
    required this.explorer,
    required this.kind,
    required this.place,
    required this.time,
    required this.likes,
    this.photo,
  });

  final String id;
  final Explorer explorer;
  final ActivityKind kind;
  final Map<String, dynamic> place;
  final String time;
  final int likes;
  final ActivityPhoto? photo;
}
