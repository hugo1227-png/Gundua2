# Fotografias da atividade da comunidade

As fotografias foram redimensionadas e convertidas para WebP. As adaptações das fotografias com licença Creative Commons mantêm a licença da fotografia original.

- **Estufa Fria** (`friends_estufa_fria.webp`), fotografia de 0000ff. [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Estufa-Fria-Lisboa-2017.jpg) · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
- **Feira da Ladra** (`friends_feira_da_ladra.webp`), fotografia de Carlos Luis M C da Cruz, colocada no domínio público pelo autor. [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Feira_da_ladra.jpg)
- **Museu da Marioneta** (`friends_museu_da_marioneta.webp`), fotografia de GualdimG. [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Museu_da_Marioneta_(Lisboa)_01.jpg) · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
