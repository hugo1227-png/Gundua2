import 'package:flutter_test/flutter_test.dart';
import 'package:proto_2/models/community_activity.dart';
import 'package:proto_2/services/explorer_matching_service.dart';
import 'package:proto_2/services/location_service.dart';

void main() {
  final matcher = ExplorerMatchingService();
  const near = Explorer(
    id: 'near',
    name: 'Ana',
    area: 'Lisboa',
    latitude: 38.72,
    longitude: -9.14,
    visits: [
      {'category': 'Natureza'},
    ],
    favorites: [
      {'placeId': 'garden'},
    ],
  );
  const far = Explorer(
    id: 'far',
    name: 'Bruno',
    area: 'Porto',
    latitude: 41.15,
    longitude: -8.61,
    visits: [
      {'category': 'Museu'},
    ],
    favorites: [
      {'placeId': 'museum'},
    ],
  );
  const lisbon = AppLocation(
    label: 'Lisboa',
    latitude: 38.72,
    longitude: -9.14,
    isDeviceLocation: false,
  );

  test('Monte Carlo ranking is stable and uses each matching signal', () {
    final signals =
        <
          ({
            List<Map<String, dynamic>> visits,
            List<Map<String, dynamic>> favorites,
            AppLocation? location,
          })
        >[
          (
            visits: [
              {
                'categories': ['leisure.park'],
              },
            ],
            favorites: [],
            location: null,
          ),
          (
            visits: [],
            favorites: [
              {'place_id': 'garden'},
            ],
            location: null,
          ),
          (visits: [], favorites: [], location: lisbon),
        ];

    for (final signal in signals) {
      List<ExplorerMatch> rank() => matcher.rank(
        explorers: const [far, near],
        visits: signal.visits,
        favorites: signal.favorites,
        location: signal.location,
      );

      final matches = rank();
      expect(matches.map((match) => match.explorer), [near, far]);
      expect(matches.first.percent, greaterThan(matches.last.percent));
      expect(matches, rank());
    }
  });

  test('missing history and location give a neutral initial estimate', () {
    final matches = matcher.rank(
      explorers: const [far, near],
      visits: const [],
      favorites: const [],
    );

    expect(matches.map((match) => match.percent), [50, 50]);
  });
}
