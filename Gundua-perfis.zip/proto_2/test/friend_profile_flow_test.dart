import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:proto_2/screens/friends_feed.dart';
import 'package:proto_2/screens/user_profile_screen.dart';
import 'package:proto_2/theme/gundua_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('both Friends entries share the persisted follow state', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    tester.view
      ..devicePixelRatio = 1
      ..physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    Map<String, dynamic>? openedPlace;
    await tester.pumpWidget(
      MaterialApp(
        theme: GunduaTheme.light(),
        home: Scaffold(
          body: SingleChildScrollView(
            child: FriendsFeed(
              onOpenPlace: (place) async => openedPlace = place,
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final name = find.text('Inês Matos');
    final profile = find.byType(UserProfileScreen);
    Finder profileText(String label) =>
        find.descendant(of: profile, matching: find.text(label));

    await tester.tap(name.first);
    await tester.pumpAndSettle();
    expect(profileText('Inês Matos'), findsOneWidget);
    expect(profileText('127'), findsOneWidget);
    expect(profileText('86'), findsOneWidget);
    expect(profileText('2'), findsOneWidget);
    expect(profileText('Atividade recente'), findsOneWidget);
    await tester.tap(profileText('Estufa Fria').first);
    await tester.pumpAndSettle();
    expect(openedPlace?['placeId'], 'lisbon-hidden-estufa-fria');

    await tester.tap(profileText('Seguir'));
    await tester.pumpAndSettle();
    expect(profileText('128'), findsOneWidget);
    expect(profileText('Seguindo'), findsOneWidget);

    final preferences = await SharedPreferences.getInstance();
    const followsKey = 'gundua_followed_explorers';
    expect(preferences.getStringList(followsKey), ['demo-ines']);

    await tester.pageBack();
    await tester.pumpAndSettle();
    expect(find.text('Seguindo'), findsOneWidget);
    await tester.ensureVisible(name.last);
    await tester.tap(name.last);
    await tester.pumpAndSettle();
    expect(profileText('Inês Matos'), findsOneWidget);
    expect(profileText('128'), findsOneWidget);

    await tester.tap(profileText('Seguindo'));
    await tester.pumpAndSettle();
    expect(profileText('127'), findsOneWidget);
    expect(profileText('Seguir'), findsOneWidget);
    expect(preferences.getStringList(followsKey), isEmpty);
  });
}
