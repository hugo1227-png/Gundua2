import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:proto_2/services/community_places_service.dart';
import 'package:proto_2/services/favorites_service.dart';
import 'package:proto_2/services/gundua_api_client.dart';
import 'package:proto_2/services/local_reviews_service.dart';
import 'package:proto_2/services/place_search_service.dart';
import 'package:proto_2/services/place_service.dart';
import 'package:proto_2/services/visited_places_service.dart';

class _OfflinePlaces extends PlaceService {
  @override
  Future<List<Map<String, dynamic>>> searchPlaces(String query) async =>
      throw StateError('offline');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test(
    'keeps both contributions when saved together and restores their photo',
    () async {
      final local = CommunityPlacesService();
      final photo = Uint8List.fromList([1, 3, 4]);
      final saves = await Future.wait([
        local.add(
          name: ' Pátio das Flores ',
          category: 'Natureza',
          categories: ['natural'],
          address: ' Rua das Flores, São Luís ',
          description: ' Jardim comunitário ',
          photo: photo,
        ),
        local.add(
          name: 'Museu da Cidade',
          category: 'Museus',
          categories: ['entertainment.museum'],
          address: 'Praça Central, São Luís',
          description: 'Museu municipal',
        ),
      ]);

      final restored = CommunityPlacesService();
      await restored.load();

      expect(
        restored.places.map((place) => place.id),
        saves.reversed.map((place) => place.id),
      );
      final garden = restored.places.last;
      expect(garden.name, 'Pátio das Flores');
      expect(garden.toMap()['latitude'], isNull);
      expect(CommunityPlacesService.isLocalPhoto(garden.imageUrl!), isTrue);
      expect(restored.photo(garden.imageUrl!), photo);
    },
  );

  test(
    'finds contributions offline using accents and category filters',
    () async {
      final local = CommunityPlacesService();
      final place = await local.add(
        name: 'Pátio das Flores',
        category: 'Natureza',
        categories: ['natural'],
        address: 'Rua das Flores, São Luís',
        description: 'Jardim comunitário',
      );
      final search = PlaceSearchService(
        placeService: _OfflinePlaces(),
        communityPlaces: local,
      );

      final results = await search.search(
        placeQuery: 'patio',
        locationQuery: 'sao luis',
        category: 'Natureza',
      );
      expect(results.single['placeId'], place.id);
      expect(
        search.localMatches(placeQuery: 'patio', category: 'Museus'),
        isEmpty,
      );
      expect(search.localMatches(locationQuery: 'Lisboa'), isEmpty);
    },
  );
  test(
    'keeps contributed-place interactions local when the API is configured',
    () async {
      final place = (await CommunityPlacesService().add(
        name: 'Pátio das Flores',
        category: 'Natureza',
        categories: ['natural'],
        address: 'Rua das Flores, São Luís',
        description: 'Jardim comunitário',
      )).toMap();
      final id = place['placeId'] as String;
      final favorites = FavoritesService();
      final visits = VisitedPlacesService();
      final reviews = LocalReviewsService();
      final requests = <String>[];
      final expectedItems = GunduaApiClient.isConfigured ? 2 : 1;

      await http.runWithClient(
        () async {
          expect(await favorites.toggleFavorite(place), isTrue);
          expect(await visits.toggleVisited(place), isTrue);
          await reviews.save(
            place: place,
            rating: 5,
            comment: 'Vale a visita.',
          );

          expect(await favorites.isFavorite(place), isTrue);
          expect(await visits.isVisited(place), isTrue);
          expect((await reviews.forPlace(id))?['rating'], 5);
          expect(await favorites.getFavorites(), hasLength(expectedItems));
          expect(await visits.getVisitedPlaces(), hasLength(expectedItems));
          expect(await reviews.getReviews(), hasLength(expectedItems));

          expect(await favorites.toggleFavorite(place), isFalse);
          expect(await visits.toggleVisited(place), isFalse);
          await reviews.delete(id);
          expect(await reviews.forPlace(id), isNull);
        },
        () => MockClient((request) async {
          requests.add('${request.method} ${request.url.path}');
          return http.Response('{"items":[{"name":"Remote attraction"}]}', 200);
        }),
      );

      expect(
        requests,
        GunduaApiClient.isConfigured
            ? ['GET /me/favorites', 'GET /me/visits', 'GET /me/reviews']
            : isEmpty,
      );
    },
  );
  test('preserves simultaneous local favorites and visits', () async {
    final first = {'isCommunityPlace': true, 'placeId': 'community-first'};
    final second = {'isCommunityPlace': true, 'placeId': 'community-second'};
    final favorites = FavoritesService();
    final visits = VisitedPlacesService();
    await Future.wait([
      favorites.toggleFavorite(first),
      favorites.toggleFavorite(second),
      visits.toggleVisited(first),
      visits.toggleVisited(second),
    ]);
    expect(await favorites.isFavorite(first), isTrue);
    expect(await favorites.isFavorite(second), isTrue);
    expect(await visits.isVisited(first), isTrue);
    expect(await visits.isVisited(second), isTrue);
  });
}
